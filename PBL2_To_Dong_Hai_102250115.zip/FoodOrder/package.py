from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib

root=Path(__file__).resolve().parent
files=[root/x for x in ['FoodOrder.exe','README.md','build.bat','run.bat','test.bat','CMakeLists.txt','.clang-format','package.py']]
files+=list((root/'src').glob('*'))
files+=[root/'tests'/x for x in ['test_core.cpp','results.txt','ui-results.txt']]
files+=[root/'assets'/'reference-logo-0.png']
files+=[p for p in (root/'report').iterdir() if p.is_file() and p.suffix in {'.py','.json','.png','.pdf','.docx'}]
files+=list((root/'report'/'screenshots').glob('*.png'))
target=root.parent/'PBL2_To_Dong_Hai_102250115.zip'
with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        assert p.exists(),p
        z.write(p,Path('FoodOrder')/p.relative_to(root))
with ZipFile(target) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert 'FoodOrder/FoodOrder.exe' in names
    assert 'FoodOrder/report/Bao_cao_PBL2_To_Dong_Hai.pdf' in names
    assert not any('/qa-data/' in n or '/tools/' in n or '/render/' in n for n in names)
print('ZIP:',target)
print('Files:',len(files),'Bytes:',target.stat().st_size)
print('SHA256:',hashlib.sha256(target.read_bytes()).hexdigest())
