from pathlib import Path
import json, sys, re
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.enum.section import WD_SECTION_START
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'report'
PAGES=json.loads((OUT/'content.json').read_text(encoding='utf-8'))
FONT='C:/Windows/Fonts/times.ttf'
def imfont(n,bold=False):return ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf',n)
def relation():
    im=Image.new('RGB',(1500,830),'white');d=ImageDraw.Draw(im)
    def node(x,y,title,lines):
        d.rectangle((x,y,x+390,y+175),fill='#fffff5',outline='#222222',width=3)
        d.line((x,y+52,x+390,y+52),fill='#333333',width=2)
        d.text((x+15,y+10),title,font=imfont(28,True),fill='black')
        for i,t in enumerate(lines):d.text((x+15,y+65+i*34),t,font=imfont(23),fill='black')
    def arrow(a,b,label):
        d.line((*a,*b),fill='#333333',width=3)
        x,y=b;d.polygon([(x,y),(x-14,y-7),(x-14,y+7)],fill='#333333')
        d.text(((a[0]+b[0])/2-30,(a[1]+b[1])/2-34),label,font=imfont(24),fill='black')
    node(30,70,'User',['id','name, login, admin'])
    node(555,70,'Order',['id, userId, status','total, coupon, items'])
    node(1080,70,'OrderItem',['foodId, name, price','quantity, note'])
    node(30,540,'Discount',['code','amount, remaining'])
    node(555,540,'Payment',['orderId, reference','amount, method, status'])
    node(1080,540,'FoodItem',['id, name, price','category, available'])
    arrow((420,145),(555,145),'1 : N');arrow((945,145),(1080,145),'1 : N')
    d.line((750,245,750,540),fill='black',width=3);d.text((770,365),'1 : N',font=imfont(25),fill='black')
    d.line((1275,245,1275,540),fill='black',width=3);d.text((1300,365),'N : 1',font=imfont(25),fill='black')
    d.line((420,620,485,620,485,245,555,245),fill='black',width=3)
    d.text((35,460),'Discount 0..1 / Order',font=imfont(24),fill='black')
    im.save(OUT/'relations.png')
relation()

def uml(filename,classes):
    im=Image.new('RGB',(1500,1050),'white');d=ImageDraw.Draw(im)
    for col,(title,attrs,methods) in enumerate(classes):
        x=35+col*750;y=35;right=x+680
        d.rectangle((x,y,right,1010),fill='#fffff8',outline='black',width=3)
        d.text((x+25,y+20),title,font=imfont(35,True),fill='black')
        d.line((x,105,right,105),fill='black',width=2)
        cy=130
        for s in attrs:d.text((x+20,cy),s,font=imfont(25),fill='black');cy+=43
        cy=max(cy+15,510);d.line((x,cy,right,cy),fill='black',width=2);cy+=25
        for s in methods:d.text((x+20,cy),s,font=imfont(25),fill='black');cy+=43
    im.save(OUT/filename)
uml('classes-account.png',[
('User',['+ id: int','+ name, email, phone: string','+ login, saltValue: string','+ digest: string','+ admin: bool'],['Dữ liệu tài khoản','Xác thực do Store thực hiện']),
('FoodItem',['+ id: int','+ name, category: string','+ description: string','+ price: Money','+ available: bool','+ art: int'],['Dữ liệu thực đơn','Cập nhật qua Store::saveFood'])])
uml('classes-order.png',[
('Order',['+ id, userId: int','+ created, receiver: string','+ note, coupon: string','+ items: vector<OrderItem>','+ subtotal, discount: Money','+ total: Money','+ status: int'],['Chứa các dòng OrderItem','Nghiệp vụ do Store điều phối']),
('Payment',['+ id, orderId: int','+ method, created: string','+ reference: string','+ amount: Money','+ status: int'],['0: Chờ xử lý','1: Thành công','2: Thất bại'])])
uml('classes-store.png',[
('Store',['- s: State','- files: FileManager'],['+ login / registerUser','+ saveFood / toggleFood','+ place / order / cancel','+ advance / pay / paid','+ createDiscount / revenue','- commit / admin']),
('FileManager',['- path: filesystem::path'],['+ exists(): bool','+ load(): State','+ save(const State&): void'])])
# Add concrete class diagrams, as in the reference report.
insert_at=next(i for i,p in enumerate(PAGES) if any(b[0]=='fig' and b[1][0]=='relations.png' for b in p['blocks']))
for offset,(file,cap,explanation) in enumerate([
('classes-account.png','Hình 4.1-1. Thuộc tính của User và FoodItem','Hai cấu trúc lưu tài khoản và thực đơn. Các trường dữ liệu không tự thực hiện xác thực hay ghi tệp. Store sử dụng các cấu trúc này để kiểm tra và cập nhật theo quyền.'),
('classes-order.png','Hình 4.1-2. Thuộc tính của Order và Payment','Order biểu diễn yêu cầu món ăn đã xác nhận. Payment biểu diễn từng lần thanh toán. Tách hai cấu trúc giúp một đơn có thể thử thanh toán thất bại rồi thử lại mà không mất lịch sử.'),
('classes-store.png','Hình 4.1-3. Thuộc tính và phương thức của Store và FileManager','Store giữ State riêng và cung cấp phương thức nghiệp vụ. FileManager chỉ phụ trách lưu trữ. Dấu cộng biểu diễn thành phần công khai; dấu trừ biểu diễn thành phần riêng tư.')]):
    PAGES.insert(insert_at+offset,{'title':'4. ỨNG DỤNG HƯỚNG ĐỐI TƯỢNG VÀO BÀI TOÁN','blocks':[('h','4.1.5. Sơ đồ các lớp và cấu trúc'),('fig',(file,cap)),('p',explanation)]})

doc=Document()
sec=doc.sections[0]
sec.page_width=Cm(21);sec.page_height=Cm(29.7)
sec.top_margin=Cm(2);sec.bottom_margin=Cm(2);sec.left_margin=Cm(3);sec.right_margin=Cm(2)
sec.header_distance=Cm(.9);sec.footer_distance=Cm(.9)
normal=doc.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(14)
normal.paragraph_format.line_spacing=Pt(20)
normal.paragraph_format.space_after=Pt(6)
for name,size in [('Title',22),('Heading 1',15),('Heading 2',13),('Caption',12)]:
    st=doc.styles[name];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
    st.paragraph_format.space_before=Pt(7);st.paragraph_format.space_after=Pt(7)
    st.paragraph_format.line_spacing=1.1
    if name.startswith('Heading'):st.font.bold=True
doc.styles['Caption'].font.italic=True
doc.styles['Caption'].font.color.rgb=RGBColor.from_string('3B4F6A')
for name in ['Normal','Title','Heading 1','Heading 2','Caption']:
    rf=doc.styles[name].element.get_or_add_rPr().get_or_add_rFonts()
    for attr in list(rf.attrib):
        if 'Theme' in attr:del rf.attrib[attr]
    for attr in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+attr),'Times New Roman')
doc.core_properties.title='Xây dựng ứng dụng đặt món ăn và thanh toán đơn hàng'
doc.core_properties.author='Tô Đông Hải'
doc.core_properties.subject='PBL2 - Dự án cơ sở lập trình'

def border(section):
    e=OxmlElement('w:pgBorders');e.set(qn('w:offsetFrom'),'page')
    for side in ['top','left','bottom','right']:
        b=OxmlElement('w:'+side)
        for k,v in [('val','double'),('sz','12'),('space','24'),('color','000066')]:b.set(qn('w:'+k),v)
        e.append(b)
    section._sectPr.append(e)
border(sec)
def coverline(s,size=16,bold=True,before=0,after=0):
    q=doc.add_paragraph();q.alignment=WD_ALIGN_PARAGRAPH.CENTER
    q.paragraph_format.space_before=Pt(before);q.paragraph_format.space_after=Pt(after)
    q.paragraph_format.line_spacing=1.15
    r=q.add_run(s);r.bold=bold;r.font.size=Pt(size)
    return q
coverline('ĐẠI HỌC ĐÀ NẴNG',16)
coverline('ĐẠI HỌC BÁCH KHOA',16)
coverline('KHOA CÔNG NGHỆ THÔNG TIN',16,after=40)
q=doc.add_paragraph();q.alignment=WD_ALIGN_PARAGRAPH.CENTER
q.paragraph_format.line_spacing=1.0
q.add_run().add_picture(str(ROOT/'assets'/'reference-logo-0.png'),width=Cm(1.9))
coverline('PBL2: DỰ ÁN CƠ SỞ LẬP TRÌNH',21,before=48,after=18)
coverline('Đề tài: Xây dựng ứng dụng đặt món ăn\nvà thanh toán đơn hàng',17,after=75)
coverline('SINH VIÊN THỰC HIỆN',14,after=12)
coverline('Tô Đông Hải',15,after=8)
coverline('Mã sinh viên: 102250115',14,after=8)
coverline('Lớp: ........................     Nhóm: ........................',13,after=24)
coverline('GIẢNG VIÊN HƯỚNG DẪN',14,after=12)
coverline('Trương Ngọc Châu',15,after=65)
coverline('Đà Nẵng - 10/2026',13)
sec=doc.add_section(WD_SECTION_START.NEW_PAGE)
for e in list(sec._sectPr):
    if e.tag==qn('w:pgBorders'):sec._sectPr.remove(e)
sec.header.is_linked_to_previous=False;sec.footer.is_linked_to_previous=False
num=OxmlElement('w:pgNumType');num.set(qn('w:start'),'1');sec._sectPr.append(num)
hp=sec.header.paragraphs[0];hp.text='PBL 2: DỰ ÁN CƠ SỞ LẬP TRÌNH'
hp.runs[0].font.size=Pt(12);hp.runs[0].font.color.rgb=RGBColor.from_string('555555')
fp=sec.footer.paragraphs[0];fp.style='Normal';fp.paragraph_format.tab_stops.clear_all();fp.paragraph_format.tab_stops.add_tab_stop(Cm(16),WD_TAB_ALIGNMENT.RIGHT)
fp.add_run('Tô Đông Hải - 102250115\tTrang ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');fp._p.append(fld)
for r in fp.runs:r.font.size=Pt(11)
pb=OxmlElement('w:pBdr');b=OxmlElement('w:top');b.set(qn('w:val'),'single');b.set(qn('w:sz'),'4');b.set(qn('w:color'),'000099');pb.append(b);fp._p.get_or_add_pPr().append(pb)

# Page entries use explicit page breaks, hence references remain deterministic.
toc=[];figures=[];seen=set()
for no,page in enumerate(PAGES,1):
    title=page['title']
    if title not in seen and title not in ('MỤC LỤC','DANH MỤC HÌNH VẼ'):
        toc.append((title,no,0));seen.add(title)
    for typ,data in page['blocks']:
        if typ=='h' and data.startswith('5.2.1.') and '5.2.' not in seen:
            toc.append(('5.2. Kết quả thực thi của chương trình',no,1));seen.add('5.2.')
        if typ=='h' and re.match(r'^\d\.\d\. ',data) and data not in seen:
            toc.append((data,no,1));seen.add(data)
        if typ=='fig':figures.append((data[1],no))

def para(s,small=False):
    q=doc.add_paragraph(s);q.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    q.paragraph_format.first_line_indent=Cm(.65)
    if small:
        q.paragraph_format.line_spacing=Pt(14);q.paragraph_format.space_after=Pt(4)
        for r in q.runs:r.font.size=Pt(11.5)
    return q
def listentry(title,no,indent=0):
    q=doc.add_paragraph();q.paragraph_format.left_indent=Cm(.4*indent)
    q.paragraph_format.tab_stops.add_tab_stop(Cm(16-.4*indent),WD_TAB_ALIGNMENT.RIGHT,WD_TAB_LEADER.DOTS)
    q.paragraph_format.space_after=Pt(5);q.paragraph_format.line_spacing=Pt(15)
    r=q.add_run(title+'\t'+str(no));r.font.size=Pt(11.5)

for no,page in enumerate(PAGES,1):
    if no>1:doc.add_page_break()
    q=doc.add_paragraph(page['title'],'Heading 1')
    q.paragraph_format.space_before=Pt(0)
    isshots=any(t=='fig' and d[0].startswith('screenshots/') for t,d in page['blocks'])
    if isshots:
        for r in q.runs:r.font.size=Pt(13)
    for typ,data in page['blocks']:
        if typ=='p':para(data,isshots)
        elif typ=='h':
            q=doc.add_paragraph(data,'Heading 2')
            if isshots:
                q.paragraph_format.space_before=Pt(3);q.paragraph_format.space_after=Pt(3)
                for r in q.runs:r.font.size=Pt(12)
        elif typ=='list':
            for s in data:
                q=doc.add_paragraph('− '+s);q.paragraph_format.left_indent=Cm(.5)
                q.paragraph_format.first_line_indent=Cm(-.35);q.paragraph_format.space_after=Pt(4)
        elif typ=='table':
            headers,rows=data;t=doc.add_table(rows=1,cols=len(headers));t.style='Table Grid'
            t.autofit=False
            widths=([4,12] if len(headers)==2 else [5.3,7.5,3.2])
            if len(headers)==3 and headers[0]=='Thao tác':widths=[4.1,5.3,6.6]
            if len(headers)==3 and headers[0]=='Trạng thái đơn':widths=[5,2,9]
            for i,c in enumerate(t.columns):c.width=Cm(widths[i])
            for i,s in enumerate(headers):t.rows[0].cells[i].text=s
            for row in rows:
                cells=t.add_row().cells
                for i,s in enumerate(row):cells[i].text=s
            for ri,row in enumerate(t.rows):
                trPr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trPr.append(cant)
                for i,c in enumerate(row.cells):
                    c.width=Cm(widths[i])
                    for q in c.paragraphs:
                        q.paragraph_format.space_after=Pt(4);q.paragraph_format.space_before=Pt(4)
                        q.paragraph_format.line_spacing=Pt(15)
                        for r in q.runs:r.font.size=Pt(11.5);r.bold=(ri==0)
                    if ri==0:
                        shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'F1F1E8');c._tc.get_or_add_tcPr().append(shade)
            q=doc.add_paragraph();q.paragraph_format.space_after=Pt(1);q.paragraph_format.line_spacing=Pt(1);q.add_run().font.size=Pt(1)
        elif typ=='fig':
            filename,caption=data
            q=doc.add_paragraph();q.alignment=WD_ALIGN_PARAGRAPH.CENTER
            q.paragraph_format.space_after=Pt(0);q.paragraph_format.space_before=Pt(0)
            q.paragraph_format.line_spacing=1.0
            q.paragraph_format.keep_with_next=True
            width=14.7 if filename.startswith('screenshots/') else 16
            q.add_run().add_picture(str(OUT/filename),width=Cm(width))
            q=doc.add_paragraph(caption,'Caption');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
            q.paragraph_format.space_before=Pt(1);q.paragraph_format.space_after=Pt(4)
            if isshots:
                for r in q.runs:r.font.size=Pt(11)
        elif typ=='toc':
            for title,pg,indent in toc:listentry(title,pg,indent)
        elif typ=='figlist':
            for title,pg in figures:listentry(title,pg)

doc.save(OUT/'Bao_cao_PBL2_To_Dong_Hai.docx')
(OUT/'page_map.json').write_text(json.dumps(PAGES,ensure_ascii=False,indent=2),encoding='utf-8')
print('Expected physical pages:',len(PAGES)+1)
print('DOCX saved')
