from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
pages=[]
def page(title,*blocks): pages.append({'title':title,'blocks':list(blocks)})
def p(s): return ('p',s)
def h(s): return ('h',s)
def li(*s): return ('list',list(s))
def table(headers,rows): return ('table',(headers,rows))
def fig(name,caption): return ('fig',(name,caption))
page('LỜI MỞ ĐẦU',
p('Hoạt động tiếp nhận món ăn và thanh toán tại cửa hàng yêu cầu sự chính xác về tên món, số lượng, ghi chú chế biến và số tiền phải thu. Khi thực hiện bằng cách ghi chép thủ công, người bán có thể bỏ sót yêu cầu của khách, tính nhầm tổng tiền hoặc gặp khó khăn khi tra cứu đơn đã xử lý. Một ứng dụng có giao diện trực quan giúp tập trung thông tin và tổ chức quy trình phục vụ rõ ràng hơn.'),
p('Từ bài toán trên, em thực hiện đề tài “Xây dựng ứng dụng đặt món ăn và thanh toán đơn hàng”. Chương trình hỗ trợ khách hàng xem thực đơn, tìm món, quản lý giỏ hàng, đặt đơn và kiểm tra tình trạng thanh toán. Người quản lý có thể cập nhật thực đơn, tiếp nhận đơn, xác nhận tiền mặt và theo dõi tổng tiền đã thu.'),
p('Đề tài vận dụng ngôn ngữ C++17, cấu trúc dữ liệu vector, xử lý tệp và tổ chức lớp để xây dựng ứng dụng Windows. Giao diện sử dụng Win32 và GDI+, với bố trí nền vàng nhạt, các khối món ăn, nút thao tác và thanh điều hướng. Phạm vi triển khai là một cửa hàng, nhận món tại quầy; thanh toán điện tử được mô phỏng để kiểm tra luồng xử lý.'),
p('Báo cáo trình bày quá trình phân tích chức năng, thiết kế dữ liệu, tổ chức lớp, kết quả thực thi và kiểm thử chương trình. Các chức năng chưa triển khai được nêu trong phần hạn chế, làm cơ sở cho việc phát triển tiếp theo.'),
p('Em xin cảm ơn giảng viên hướng dẫn Trương Ngọc Châu đã hướng dẫn học phần và định hướng thực hiện đề tài. Em mong nhận được ý kiến góp ý để hoàn thiện thiết kế và chương trình.'))
page('MỤC LỤC',('toc',None))
page('DANH MỤC HÌNH VẼ',('figlist',None))
page('1. GIỚI THIỆU ĐỀ TÀI',
h('1.1. Bài toán và mục tiêu'),
p('Ứng dụng đặt món ăn và thanh toán đơn hàng phục vụ hai nhóm người dùng: khách hàng và quản trị viên cửa hàng. Khách hàng cần biết món đang bán, giá bán và nội dung món trước khi đặt. Người quản lý cần tiếp nhận đúng đơn, biết đơn đã thu tiền hay chưa và theo dõi quá trình chuẩn bị món.'),
p('Mục tiêu của chương trình là hoàn thành một quy trình liên tục từ lựa chọn món đến ghi nhận thanh toán. Dữ liệu đơn hàng phải giữ được thông tin tại thời điểm đặt, kể cả khi thực đơn thay đổi về sau. Các thao tác không hợp lệ như đặt giỏ rỗng, xác nhận tiền mặt bởi khách hàng hoặc thanh toán thành công hai lần phải bị ngăn chặn.'),
h('1.2. Đối tượng sử dụng'),
li('Khách hàng: đăng ký, đăng nhập, tìm món, đặt đơn, xem lịch sử và đổi mật khẩu.','Quản trị viên: quản lý khách hàng, thực đơn, đơn hàng, mã giảm giá và thống kê tiền đã thu.'),
h('1.3. Phạm vi triển khai'),
p('Chương trình chạy cục bộ trên Windows với một tệp dữ liệu và một tiến trình ứng dụng. Khách đặt món và nhận tại cửa hàng. Hai phương thức thanh toán là tiền mặt do quản trị viên xác nhận và thanh toán mô phỏng thành công hoặc thất bại. Chương trình không kết nối ngân hàng, ví điện tử hoặc đơn vị giao hàng.'))
page('1. GIỚI THIỆU ĐỀ TÀI',
h('1.4. Dữ liệu và yêu cầu tổng quát'),
p('Hệ thống quản lý tài khoản, món ăn, giỏ hàng, đơn hàng, chi tiết đơn, giao dịch thanh toán và mã giảm giá. Tài khoản xác định danh tính và vai trò. Món ăn cung cấp thông tin phục vụ lựa chọn. Đơn hàng lưu thông tin người nhận, thời gian, tổng tiền và các món đã được xác nhận.'),
table(['Nhóm yêu cầu','Nội dung'],[['Chức năng','Đăng nhập; xem và tìm món; đặt đơn; thanh toán; quản trị.'],['Tính đúng đắn','Giá và số lượng hợp lệ; giữ giá lịch sử; không ghi thu tiền hai lần.'],['Lưu trữ','Đọc lại được dữ liệu sau khi đóng và mở chương trình.'],['Giao diện','Hiển thị tiếng Việt; thao tác bằng chuột; biểu mẫu rõ ràng.'],['Phân quyền','Khách chỉ xem đơn của mình; quản trị viên quản lý cửa hàng.']]),
h('1.5. Phương pháp thực hiện'),
li('Phân tích các bước đặt món và xác định điều kiện trước, sau mỗi thao tác.','Thiết kế các cấu trúc dữ liệu và tách nghiệp vụ khỏi phần vẽ giao diện.','Cài đặt chức năng theo luồng khách hàng và quản trị viên.','Chạy kiểm thử nghiệp vụ, kiểm tra giao diện và đối chiếu kết quả với yêu cầu.'),
p('Bố cục báo cáo gồm sáu chương: giới thiệu; phân tích chức năng; thiết kế cấu trúc dữ liệu; ứng dụng hướng đối tượng; chương trình và kết quả; kết luận và hướng phát triển.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.1. Chức năng quản lý khách hàng, món ăn và đơn hàng'),
p('Hệ thống tổ chức chức năng theo quyền của người đang đăng nhập. Cùng dữ liệu đơn hàng được sử dụng cho lịch sử của khách và màn hình quản lý của cửa hàng, nhưng điều kiện truy cập khác nhau. Việc kiểm tra quyền được thực hiện trong lớp Store, không chỉ dựa trên việc ẩn nút giao diện.'),
table(['Đối tượng','Chức năng đã cài đặt'],[['Tài khoản','Đăng ký, đăng nhập, xem thông tin, đổi mật khẩu.'],['Món ăn','Hiển thị, tìm tên, lọc danh mục, thêm, sửa, mở/ngừng bán.'],['Giỏ hàng','Thêm món, tăng/giảm số lượng, xóa dòng, tính tạm tính.'],['Đơn hàng','Tạo đơn, xem chi tiết, hủy đơn đủ điều kiện, chuyển trạng thái.'],['Thanh toán','Tiền mặt; mô phỏng; ghi thành công/thất bại; thử lại.'],['Giảm giá','Tạo mã, giới hạn lượt, áp dụng mức giảm cố định.'],['Thống kê','Tổng tiền đã thu và biểu đồ theo ngày có giao dịch.']]),
p('Danh mục ban đầu gồm Món chính, Món phụ, Đồ uống và Tráng miệng. Thực đơn mẫu có 12 món, trong đó một món đang ngừng bán để minh họa kiểm tra trạng thái. Tài khoản mẫu phục vụ chạy thử; người dùng có thể tạo tài khoản mới.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.2. Thao tác với dữ liệu lưu trữ'),h('2.2.1. Đọc dữ liệu'),
p('Lớp FileManager mở tệp data/store.txt và kiểm tra dòng nhận dạng FOODORDER 1. Phần tiếp theo lưu các bộ đếm mã, số lượng phần tử và nội dung từng nhóm đối tượng. Chuỗi được đọc bằng std::quoted để bảo toàn dấu cách và ký tự đặt trong dấu ngoặc kép.'),
li('Mở tệp ở chế độ nhị phân để xử lý nội dung UTF-8 ổn định.','Kiểm tra tên định dạng và phiên bản trước khi đọc dữ liệu.','Đọc số lượng phần tử; từ chối số lượng vượt giới hạn.','Đọc từng bản ghi; kiểm tra lỗi đọc và giá món.','Trả về State khi dữ liệu đầy đủ; báo lỗi khi tệp bị cắt ngắn.'),
h('2.2.2. Ghi dữ liệu'),
p('FileManager ghi toàn bộ trạng thái vào tệp tạm có hậu tố .tmp. Sau khi kiểm tra ghi và đóng tệp thành công, chương trình thay tệp chính bằng MoveFileExW. Mỗi lần cập nhật dùng một bản sao State để phục hồi dữ liệu trong bộ nhớ nếu lưu thất bại.'),
p('Cách tổ chức này giảm nguy cơ một đơn đã được thêm trong bộ nhớ nhưng chưa được lưu xuống tệp. Đây là cơ chế lưu cục bộ cho đồ án, không thay thế hệ quản trị cơ sở dữ liệu có giao dịch hoặc giải pháp phục hồi khi mất điện.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.3. Các phương thức chính của khách hàng'),h('2.3.1. Đăng ký tài khoản'),
p('Khách nhập họ tên, email, số điện thoại, tên đăng nhập, mật khẩu và mật khẩu xác nhận. Giao diện kiểm tra hai mật khẩu trùng nhau. Store kiểm tra tên đăng nhập chưa tồn tại, mật khẩu tối thiểu sáu ký tự và dữ liệu liên hệ phù hợp với các kiểm tra cơ bản.'),
li('Kiểm tra họ tên và tên đăng nhập không rỗng, giới hạn độ dài.','Kiểm tra email có ký tự @; điện thoại gồm 9 đến 12 chữ số.','Sinh salt riêng, tính giá trị dẫn xuất mật khẩu và cấp mã người dùng.','Lưu tài khoản với vai trò khách; chuyển về màn hình đăng nhập.'),
h('2.3.2. Đăng nhập và đổi mật khẩu'),
p('Phương thức login tìm tài khoản theo tên đăng nhập, tính lại giá trị PBKDF2-HMAC-SHA256 với salt đã lưu và đối chiếu với dữ liệu. Khi đúng, chương trình chuyển sang thực đơn hoặc quản trị tùy vai trò. Thông báo sai không tiết lộ riêng tên tài khoản có tồn tại hay không.'),
p('Đổi mật khẩu yêu cầu người dùng đang đăng nhập, nhập đúng mật khẩu hiện tại và nhập lại mật khẩu mới. Chương trình sinh salt mới và lưu giá trị dẫn xuất mới. Phiên bản này chưa có chức năng quên mật khẩu qua email hoặc OTP.'),
p('Mật khẩu không được ghi dạng rõ vào tệp. Tài khoản mẫu và mật khẩu thử nghiệm được ghi trong hướng dẫn để phục vụ kiểm tra chức năng.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.3.3. Xem, tìm kiếm và lựa chọn món ăn'),
p('Thực đơn hiển thị theo lưới bốn cột, mỗi trang tối đa tám món. Mỗi khối gồm hình minh họa, tên, giá và nút thêm giỏ. Người dùng lọc theo danh mục hoặc nhập tên để tìm kiếm. Nhấn tên món để xem mô tả, danh mục và trạng thái bán.'),
p('Tìm kiếm duyệt danh sách và kiểm tra tên có chứa từ khóa. Hàm lower chuyển chữ về dạng thường theo khả năng xử lý của thư viện hiện tại. Chưa chuẩn hóa dấu tiếng Việt hoặc tìm kiếm không dấu; người dùng nên nhập đúng cách viết tên món.'),
h('2.3.4. Thêm món vào giỏ hàng'),
li('Lấy món theo mã và kiểm tra món còn được bán.','Nếu mã món đã có trong giỏ, tăng số lượng thêm một.','Nếu chưa có, thêm CartItem với số lượng bằng một.','Từ chối tăng nếu vượt 99 suất trên một dòng; cập nhật thông báo.'),
h('2.3.5. Tăng, giảm và xóa món'),
p('Nút cộng tăng số lượng trong giới hạn. Nút trừ giảm số lượng và xóa dòng nếu số lượng trước thao tác bằng một. Nút xóa loại bỏ dòng khỏi giỏ ngay. Tạm tính được tính lại từ giá hiện tại và số lượng. Giỏ nằm trong bộ nhớ phiên làm việc; đăng xuất hoặc đóng ứng dụng sẽ xóa giỏ chưa đặt.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.3.6. Đặt đơn hàng'),
p('Khách chuyển từ giỏ sang xác nhận, nhập người nhận/số điện thoại, ghi chú chế biến và mã giảm giá nếu có. Store::place chịu trách nhiệm kiểm tra và lưu toàn bộ đơn.'),
li('Xác thực người dùng và từ chối giỏ hàng rỗng.','Kiểm tra thông tin nhận món không rỗng, phương thức hợp lệ.','Kiểm tra món còn bán; số lượng 1 đến 99, tổng không vượt 500 suất.','Sao chép tên và đơn giá hiện tại sang OrderItem.','Tính tạm tính, kiểm tra mã giảm giá và tổng phải trả.','Lưu đơn, giảm lượt mã và tạo giao dịch chờ trong một lần commit.','Chỉ xóa giỏ và chuyển trang sau khi lưu thành công.'),
h('Công thức tính tiền'),
p('Thành tiền dòng = đơn giá tại lúc đặt × số lượng. Tạm tính là tổng thành tiền các dòng. Tiền giảm bằng giá trị mã nhưng không vượt tạm tính. Tổng thanh toán = tạm tính − tiền giảm. Phiên bản này không có phí giao hàng hoặc phụ thu.'),
p('Ví dụ: hai cơm gà giá 45.000 đồng, một gỏi cuốn giá 30.000 đồng và hai trà đào giá 25.000 đồng tạo tạm tính 170.000 đồng. HAI10 giảm 10.000 đồng, tổng thanh toán là 160.000 đồng. Giá được lưu tại lúc đặt để bảo toàn lịch sử.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.3.7. Thanh toán đơn hàng'),
p('Đặt đơn và thanh toán là hai bước độc lập. Tạo đơn thành công chỉ sinh giao dịch chờ. Trạng thái đã thanh toán chỉ xuất hiện khi một Payment của đơn được ghi nhận thành công.'),
table(['Phương thức','Cách xử lý'],[['Tiền mặt','Khách đặt đơn. Quản trị viên xác nhận đã thu tiền tại quầy.'],['Mô phỏng thành công','Kích hoạt kết quả thành công để thử luồng.'],['Mô phỏng thất bại','Ghi thất bại; không đánh dấu đơn đã thanh toán.'],['Thử lại','Tạo bản ghi mới khi không còn giao dịch chờ và đơn chưa trả tiền.']]),
p('Mỗi lần xử lý có mã tham chiếu. Nếu nhận lại cùng mã của cùng đơn, chương trình không cộng tiền lần nữa. Mã đã dùng cho đơn khác bị từ chối. Khi đơn đã có giao dịch thành công, mã thành công mới cũng không được chấp nhận.'),
p('Store::pay lấy số tiền từ đơn đã lưu, không lấy từ ô nhập. Với tiền mặt, phương thức kiểm tra người xác nhận là quản trị viên. Đơn đã hủy không thể thanh toán.'),
p('Mô phỏng chỉ thay đổi trạng thái dữ liệu nội bộ. Không có yêu cầu mạng, không truy cập ngân hàng và không phát sinh chuyển tiền thực tế.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.3.8. Xem lịch sử và hủy đơn'),
p('Lịch sử hiển thị mã đơn, thời điểm tạo, tổng tiền và trạng thái. Danh sách đọc theo thứ tự mới trước. Khi mở chi tiết, Store kiểm tra người đang đăng nhập là chủ đơn hoặc quản trị viên. Khách không thể dùng mã đơn của tài khoản khác để lấy dữ liệu.'),
p('Khách được hủy khi đơn còn chờ xác nhận và chưa có giao dịch thành công. Hộp thoại yêu cầu xác nhận trước khi hủy. Khi hủy, trạng thái đổi sang đã hủy, giao dịch chờ đổi sang thất bại và lượt mã giảm giá được hoàn lại. Không xóa bản ghi đơn khỏi lịch sử.'),
h('2.4. Các phương thức chính của quản trị viên'),h('2.4.1. Xem và tìm kiếm khách hàng'),
p('Quản trị viên xem họ tên, email và điện thoại của khách. Danh sách không hiển thị giá trị băm mật khẩu hoặc salt. Tìm kiếm theo tên; các dòng được phân trang để không vượt vùng hiển thị.'),
h('2.4.2. Tìm kiếm và sắp xếp món ăn'),
p('Màn hình món cho phép tìm tên, sắp xếp giá tăng/giảm và tên. Tìm kiếm tuyến tính tạo danh sách kết quả; std::sort sắp xếp danh sách hiển thị. Thao tác không đổi mã món và không ảnh hưởng các đơn đã lưu.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.4.3. Thêm, sửa và ngừng bán món'),
p('Biểu mẫu gồm tên, danh mục, giá và mô tả. Thêm mới cấp mã từ nextFood. Chỉnh sửa tìm món theo mã rồi thay các thuộc tính. Giá phải là số nguyên dương, không vượt 10.000.000 đồng. Danh mục và tên không được trống.'),
p('Chương trình dùng ngừng bán thay cho xóa vật lý. Món vẫn tồn tại để tham chiếu từ đơn cũ; thao tác thêm giỏ bị từ chối. Quản trị viên có thể mở bán lại. Với món đã có trong giỏ, trạng thái được kiểm tra lại khi khách xác nhận đặt đơn.'),
h('2.4.4. Tạo mã giảm giá'),
p('Mã gồm chuỗi mã, tiền giảm cố định và lượt còn lại. Chương trình từ chối mã trùng, tiền không dương và số lượt không hợp lệ. Sử dụng mã được ghi cùng đơn; hủy đủ điều kiện sẽ hoàn lượt. Phiên bản hiện tại phân biệt chữ hoa/thường và chưa có ngày hết hạn.'),
h('2.4.5. Tiếp nhận và xử lý đơn'),
p('Quản trị viên chuyển đơn tuần tự qua chờ xác nhận, đã xác nhận, đang chế biến, sẵn sàng nhận và hoàn thành. Điều kiện chuyển từ sẵn sàng nhận sang hoàn thành là đã thanh toán. Đơn hủy hoặc hoàn thành không được chuyển tiếp.'),
p('Tiến độ chuẩn bị món khác trạng thái nhận tiền. Đơn thanh toán trước vẫn cần chế biến; đơn đang chế biến có thể chưa thanh toán nếu chọn tiền mặt.'))
page('2. PHÂN TÍCH CHỨC NĂNG HỆ THỐNG',
h('2.4.6. Thống kê tiền đã thu'),
p('Màn hình thống kê cộng Payment thành công. Giao dịch chờ hoặc thất bại không đưa vào tổng. Cùng một đơn có tối đa một giao dịch thành công theo quy tắc Store::pay.'),
p('Biểu đồ nhóm theo phần ngày của thời điểm xác nhận. Chương trình hiển thị tối đa bảy ngày có giao dịch gần nhất, không phải bảy ngày liên tiếp. Ngày không có giao dịch không tạo cột. Chỉ tiêu tiền đã thu không bao gồm chi phí hoặc lợi nhuận.'),
h('2.5. Quy tắc nghiệp vụ tổng hợp'),
table(['Mã','Quy tắc'],[['R01','Giỏ có ít nhất một món khi tạo đơn.'],['R02','Món đang bán tại lúc xác nhận đơn.'],['R03','Giá lịch sử độc lập với giá hiện tại.'],['R04','Khách chỉ truy cập đơn của mình.'],['R05','Khách không tự xác nhận đã nộp tiền mặt.'],['R06','Không có hai giao dịch thành công cho cùng đơn.'],['R07','Chỉ hủy đơn chờ xác nhận và chưa trả tiền.'],['R08','Chỉ hoàn thành đơn đã thanh toán.'],['R09','Lưu thất bại phải báo lỗi và phục hồi bộ nhớ.']]),
p('Các quy tắc được dùng để xây dựng ca kiểm thử ở Chương 5.'))
page('3. THIẾT KẾ CẤU TRÚC DỮ LIỆU',
h('3.1. Phát biểu bài toán'),h('3.1.1. Mô tả đầu vào'),
p('Đầu vào gồm dữ liệu biểu mẫu, sự kiện giao diện và dữ liệu từ tệp. Dữ liệu được kiểm tra trước khi thay đổi trạng thái hệ thống.'),
table(['Nguồn','Dữ liệu'],[['Đăng ký','Họ tên, email, điện thoại, tên đăng nhập, mật khẩu.'],['Thực đơn','Mã món, từ khóa, danh mục, tiêu chí sắp xếp.'],['Giỏ hàng','Mã món, số lượng, yêu cầu thêm hoặc xóa.'],['Đặt đơn','Người nhận, ghi chú chung, mã giảm giá, phương thức.'],['Quản trị','Thông tin món, mã giảm, trạng thái, xác nhận tiền.'],['Tệp','Tài khoản, món, đơn, giao dịch và mã giảm giá.']]),
h('3.1.2. Yêu cầu đầu ra'),
p('Đầu ra là danh sách, chi tiết đơn, thông báo, biểu đồ và tệp cập nhật. Sau một giao dịch hợp lệ, trạng thái trong bộ nhớ phải thống nhất với dữ liệu đã lưu. Khi thao tác không hợp lệ, chương trình giữ trạng thái trước đó và thông báo nguyên nhân.'),
p('Tiền dùng kiểu long long, đơn vị đồng Việt Nam. Không dùng số thực cho đơn giá và tổng tiền nhằm tránh sai số làm tròn trong các phép tính của phạm vi chương trình.'))
page('3. THIẾT KẾ CẤU TRÚC DỮ LIỆU',
h('3.2. Dữ liệu tài khoản và món ăn'),
table(['Cấu trúc','Thuộc tính và ý nghĩa'],[['User','id: mã; name: họ tên; email, phone: liên hệ; login: tên đăng nhập.'],['User','saltValue: salt; digest: giá trị dẫn xuất; admin: phân quyền.'],['FoodItem','id: mã; name: tên; category: danh mục; description: mô tả.'],['FoodItem','price: giá; available: trạng thái bán; art: kiểu minh họa.'],['Discount','code: mã; amount: tiền giảm; remaining: lượt còn lại.']]),
p('Mã được cấp bằng bộ đếm trong State. Khi tạo mới thành công, bộ đếm tăng cùng lần commit. Nếu lưu thất bại, bản sao phục hồi cả danh sách và bộ đếm. Cách cấp mã phù hợp một tiến trình, không phải cơ chế cấp mã phân tán.'),
h('3.3. Dữ liệu giỏ hàng'),
p('CartItem lưu foodId, quantity và note. Vector cart ở phần giao diện chỉ tồn tại trong phiên. addCart gộp các lựa chọn cùng mã món. Ghi chú chế biến hiện nhập chung cho đơn ở màn hình xác nhận; trường note cấp dòng được dự phòng, chưa có ô sửa riêng.'),
p('Giỏ giữ mã để truy xuất tên và giá hiện tại. Khi đặt, chương trình tạo OrderItem và chụp lại tên, giá. Nhờ đó, thay đổi thực đơn không biến đổi đơn đã xác nhận.'))
page('3. THIẾT KẾ CẤU TRÚC DỮ LIỆU',
h('3.4. Dữ liệu đơn hàng và thanh toán'),
table(['Cấu trúc','Thuộc tính'],[['Order','id, userId, created, receiver, note, items, subtotal, discount, total, coupon, status.'],['OrderItem','foodId, name, price, quantity, note; total() trả thành tiền dòng.'],['Payment','id, orderId, method, created, reference, amount, status.']]),
p('Order chứa vector các OrderItem. Payment lưu riêng vì một đơn có thể thử thanh toán nhiều lần. Giao dịch thất bại vẫn được giữ. paid(orderId) kiểm tra giao dịch thành công thay vì duy trì thêm cờ dễ mất đồng bộ.'),
table(['Trạng thái đơn','Giá trị','Ý nghĩa'],[['Chờ xác nhận','0','Đơn mới, chưa tiếp nhận.'],['Đã xác nhận','1','Cửa hàng chấp nhận đơn.'],['Đang chế biến','2','Đang chuẩn bị món.'],['Sẵn sàng nhận','3','Món sẵn sàng tại quầy.'],['Hoàn thành','4','Đã nhận tiền và kết thúc.'],['Đã hủy','5','Kết thúc theo nhánh hủy.']]),
p('Payment dùng 0 cho chờ, 1 cho thành công, 2 cho thất bại. Hai nhóm trạng thái có ý nghĩa khác nhau và không được dùng thay thế lẫn nhau.'))
page('3. THIẾT KẾ CẤU TRÚC DỮ LIỆU',
h('3.5. Phân tích cấu trúc dữ liệu và giải thuật'),
p('State chứa các vector User, FoodItem, Order, Payment và Discount. Vector cung cấp truy cập theo chỉ số và tự quản lý vùng nhớ. Trong dữ liệu nhỏ của đồ án, duyệt tuyến tính giúp mã dễ theo dõi và kiểm thử.'),
table(['Thao tác','Cách thực hiện','Độ phức tạp'],[['Tìm món theo mã','Duyệt vector','O(n)'],['Tìm tên món','Duyệt và so chuỗi con','O(n × chi phí so khớp)'],['Sắp xếp món','std::sort','O(n log n) so sánh'],['Thêm vào giỏ','Tìm dòng trùng','O(k)'],['Tính tổng giỏ','Duyệt k dòng, tìm giá','O(k × n)'],['Lập đơn','Kiểm tra từng món','O(k × n), chưa tính lưu'],['Thống kê','Duyệt và nhóm ngày','O(p log d) với map'],['Lưu trạng thái','Ghi toàn bộ dữ liệu','O(S), S: kích thước']]),
p('Chi phí commit gồm sao chép State và ghi toàn bộ tệp. Khi số đơn tăng, bộ nhớ và thời gian lưu tăng theo dữ liệu. Có thể chuyển sang cơ sở dữ liệu, dùng chỉ mục và giao dịch để cập nhật phần thay đổi.'),
p('Không áp dụng tìm kiếm nhị phân trực tiếp cho điều kiện tên chứa từ khóa: điều kiện đó không bảo đảm phân hoạch đúng trên danh sách sắp theo tên.'))
page('3. THIẾT KẾ CẤU TRÚC DỮ LIỆU',
h('3.6. Tổ chức tệp và bảo toàn dữ liệu'),
p('store.txt dùng UTF-8. Dòng đầu nhận dạng định dạng; dòng kế lưu nextUser, nextFood, nextOrder, nextPayment. Mỗi nhóm bắt đầu bằng số lượng bản ghi. Order chứa số dòng OrderItem trong phần đầu. std::quoted hỗ trợ chuỗi có dấu cách và ngoặc kép.'),
table(['Thứ tự','Nội dung lưu'],[['1','FOODORDER 1 và bốn bộ đếm mã.'],['2','Số User và các tài khoản.'],['3','Số FoodItem và các món.'],['4','Số Order; mỗi đơn kèm OrderItem.'],['5','Số Payment và các giao dịch.'],['6','Số Discount và các mã.']]),
p('Chỉ một phiên ứng dụng thông thường được mở nhờ mutex. Cơ chế này hạn chế hai cửa sổ cùng ghi trong một phiên Windows. Tệp không được mã hóa; người có quyền sửa trực tiếp có thể làm sai dữ liệu. Phân quyền ứng dụng không bảo vệ trước chỉnh sửa bên ngoài.'),
p('Khi thiếu tệp ở lần chạy đầu, chương trình tạo mẫu. Khi tệp có nhưng hỏng, chương trình báo lỗi thay vì tự ghi đè. Cần sao lưu data trước khi thay đổi hoặc chuyển máy.'))
page('4. ỨNG DỤNG HƯỚNG ĐỐI TƯỢNG VÀO BÀI TOÁN',
h('4.1. Phân tích các lớp và cấu trúc'),
p('Mã nguồn tách nghiệp vụ trong core.hpp khỏi giao diện trong main.cpp. Các struct mô tả dữ liệu miền bài toán; Store và FileManager điều phối nghiệp vụ và lưu trữ.'),
table(['Thành phần','Trách nhiệm'],[['User, FoodItem','Tài khoản và món ăn.'],['CartItem','Lựa chọn tạm trong giỏ.'],['Order, OrderItem','Đơn xác nhận và các dòng lịch sử.'],['Payment, Discount','Giao dịch và ưu đãi.'],['State','Tập hợp dữ liệu và bộ đếm.'],['Store','Kiểm tra quyền, ràng buộc và cập nhật.'],['FileManager','Đọc, ghi và thay tệp dữ liệu.']]),
p('Struct dùng thành viên công khai để thuận tiện tuần tự hóa. State trong Store là riêng tư. data() trả tham chiếu const để giao diện đọc mà không sửa vector qua giao diện công khai. Các cập nhật lâu dài phải đi qua phương thức nghiệp vụ.'),
p('Chương trình áp dụng đóng gói, kết hợp đối tượng và phân tách trách nhiệm. Không xây dựng hệ phân cấp kế thừa hoặc đa hình ảo; các đặc tính này không được tuyên bố là kết quả đã áp dụng.'))
page('4. ỨNG DỤNG HƯỚNG ĐỐI TƯỢNG VÀO BÀI TOÁN',
h('4.1.1. Nhóm tài khoản và thực đơn'),
table(['Phương thức Store','Vai trò'],[['user(id)','Lấy tài khoản; báo lỗi nếu không tồn tại.'],['login(name, pass)','Xác thực đăng nhập.'],['registerUser(...)','Kiểm tra, cấp mã và lưu khách.'],['changePassword(...)','Kiểm tra mật khẩu cũ và thay giá trị dẫn xuất.'],['food(id)','Lấy món theo mã.'],['saveFood(actor, item)','Kiểm tra quyền, thêm hoặc cập nhật món.'],['toggleFood(actor, id)','Đổi trạng thái bán, giữ lịch sử.']]),
p('Sửa món không được thực hiện chỉ vì biết mã. saveFood gọi kiểm tra admin trước khi ghi. Đổi mật khẩu luôn xác thực mật khẩu hiện tại; giao diện không thay thẳng digest.'),
h('4.1.2. Nhóm đơn hàng'),
p('Order chứa OrderItem theo quan hệ thành phần: các dòng tồn tại cùng đơn. total() tính thành tiền từ giá chụp lại và số lượng. place xây đơn cục bộ trước, chỉ đưa vào State khi mọi điều kiện thỏa mãn.'),
p('order(actor, id) tập trung kiểm tra quyền xem. advance kiểm tra quyền quản trị và trạng thái. cancel dùng cùng kiểm tra quyền xem trước khi áp dụng điều kiện hủy.'))
page('4. ỨNG DỤNG HƯỚNG ĐỐI TƯỢNG VÀO BÀI TOÁN',
h('4.1.3. Nhóm thanh toán và giảm giá'),
table(['Phương thức','Vai trò'],[['paid(orderId)','Kiểm tra Payment thành công.'],['pay(actor, id, success, key)','Ghi kết quả sau khi kiểm tra quyền, mã và trạng thái.'],['revenue(day)','Cộng giao dịch thành công; có thể lọc ngày ở tầng nghiệp vụ.'],['discountFor(code, subtotal)','Kiểm tra mã và tính giảm trong giới hạn.'],['createDiscount(...)','Tạo mã khi đủ quyền và dữ liệu hợp lệ.']]),
p('Thống kê Payment tránh coi đơn chưa trả là tiền đã thu. Mã tham chiếu nhận biết xử lý lặp. Với dịch vụ thật cần xác thực thông báo từ nhà cung cấp.'),
h('4.1.4. Lớp FileManager và hàm commit'),
p('FileManager nhận đường dẫn khi khởi tạo. exists kiểm tra tệp, load đọc State và save ghi State. Lớp này không quyết định ai được thanh toán hoặc đơn nào được hủy; quy tắc đó thuộc Store.'),
p('commit nhận hàm thay đổi dữ liệu, sao chép trạng thái trước khi gọi. Nếu cập nhật hoặc ghi tệp ném ngoại lệ, trạng thái được phục hồi rồi lỗi chuyển lên giao diện. attempt bắt lỗi và hiển thị thông báo.'),
p('Tách nghiệp vụ khỏi cửa sổ giúp tests/test_core.cpp kiểm tra trực tiếp Store mà không cần mở giao diện.'))
page('4. ỨNG DỤNG HƯỚNG ĐỐI TƯỢNG VÀO BÀI TOÁN',
h('4.2. Mối quan hệ giữa các thực thể'),
fig('relations.png','Hình 4.2-1. Mối quan hệ giữa các thực thể'),
p('Một User có nhiều Order; mỗi Order chứa một hoặc nhiều OrderItem. FoodItem được tham chiếu từ nhiều dòng, đồng thời mỗi dòng lưu tên và giá lịch sử. Một Order có nhiều Payment để biểu diễn các lần thử.'),
p('Order có thể dùng một Discount qua coupon; không nhập mã thì tiền giảm bằng không. Liên kết quản lý trong C++ và tệp, không có hệ quản trị cơ sở dữ liệu tự áp đặt khóa ngoại.'),
h('4.3. Phân tách giao diện, nghiệp vụ và lưu trữ'),
p('Giao diện đọc ô nhập, gọi Store rồi vẽ lại dữ liệu. Store kiểm tra và gọi FileManager qua commit. Lỗi trả bằng ngoại lệ, chuyển thành thông báo. Thiết kế tạo điểm thay thế lưu trữ mà không buộc phần vẽ món biết chi tiết truy vấn.'))
page('5. CHƯƠNG TRÌNH VÀ KẾT QUẢ',
h('5.1. Tổ chức chương trình'),
table(['Tệp/thư mục','Vai trò'],[['src/core.hpp','Dữ liệu, lưu trữ, xác thực và nghiệp vụ.'],['src/main.cpp','Win32, GDI+, ô nhập, điều hướng và sự kiện.'],['FoodOrder.exe','Chương trình Windows đã biên dịch.'],['build.bat','Biên dịch bằng MinGW-w64 g++.'],['run.bat','Chạy ứng dụng sau giải nén.'],['tests/test_core.cpp','Kiểm thử nghiệp vụ.'],['tests/results.txt','Kết quả chạy kiểm thử.'],['data/store.txt','Dữ liệu sinh khi mở lần đầu.'],['report/screenshots','Hình giao diện kết xuất từ chương trình.']]),
p('Ngôn ngữ C++17; giao diện Win32 và GDI+; mật khẩu dùng Windows CNG qua bcrypt.dll. Thư viện chuẩn cung cấp vector, map, sort, filesystem, fstream và quoted. Không cần cài SFML để chạy bản này.'),
p('Bố trí giữ nền vàng nhạt, khối trắng, nút đỏ, lưới bốn cột và thanh quản trị bên trái. Hình món là minh họa vẽ bằng chương trình; nội dung và nút được điều chỉnh theo nghiệp vụ đặt món.'))
page('5. CHƯƠNG TRÌNH VÀ KẾT QUẢ',
h('5.1.1. Biên dịch và chạy chương trình'),
li('Giải nén toàn bộ gói vào thư mục có quyền ghi.','Chạy FoodOrder.exe hoặc run.bat. Tệp mẫu tạo khi chưa có data/store.txt.','Để biên dịch lại, dùng MinGW-w64 g++ hỗ trợ C++17 và chạy build.bat.','Chạy test.bat để biên dịch và thực thi kiểm thử.'),
table(['Vai trò','Tên đăng nhập','Mật khẩu mẫu'],[['Khách hàng','khach','Khach@123'],['Quản trị viên','admin','Admin@123']]),
p('Ứng dụng liên kết tĩnh thư viện chạy C++ và dùng DLL hệ thống Windows. Tệp thực thi được xây bằng g++ 16.1.0 trong môi trường thực hiện. Vùng nội dung cửa sổ 1100 × 650, theo bố trí cố định của đồ án.'),
h('5.1.2. Kịch bản trình diễn'),
p('Đăng nhập khách, chọn hai cơm gà, một gỏi cuốn và hai trà đào. Kiểm tra tạm tính 170.000 đồng, nhập HAI10 và tạo đơn mô phỏng tổng 160.000 đồng. Thử thất bại rồi thành công. Vào quản trị và chuyển đơn đến hoàn thành.'),
p('Kịch bản tiền mặt: khách đặt đơn; quản trị viên phải xác nhận đã thu tiền trước khi hoàn thành. Các thao tác minh họa sự tách biệt giữa đặt món, chế biến và thanh toán.'))
screens=[
('01-login','Giao diện đăng nhập','Nhập tên đăng nhập và mật khẩu. Đăng nhập hợp lệ chuyển đến thực đơn hoặc quản trị theo vai trò. Liên kết Đăng ký mở biểu mẫu tạo tài khoản.'),
('02-register','Giao diện đăng ký','Nhập họ tên, email, điện thoại và tài khoản. Mật khẩu xác nhận phải trùng; tên đăng nhập không được trùng tài khoản đã có.'),
('03-menu','Giao diện thực đơn','Lưới bốn cột, các nút danh mục, ô tìm kiếm và phân trang hỗ trợ lựa chọn. Nhấn tên để xem chi tiết, nhấn + Giỏ để thêm món.'),
('04-detail','Giao diện chi tiết món ăn','Hiển thị tên, mô tả, danh mục, trạng thái và giá. Mua ngay thêm một suất rồi chuyển đến giỏ. Thêm vào giỏ giữ nguyên trang chi tiết.'),
('05-cart','Giao diện giỏ hàng','Các món nằm bên trái; tổng tiền và Thanh toán bên phải. Khách có thể tăng, giảm hoặc xóa món trước khi tạo đơn.'),
('06-checkout','Giao diện xác nhận đặt món','Nhập người nhận, ghi chú và mã giảm. Chọn tiền mặt hoặc mô phỏng. Nút Đặt đơn hàng lưu đơn nhưng chưa xác nhận đã trả tiền.'),
('07-payment','Giao diện thanh toán mô phỏng','Đơn chưa thanh toán có các nút thử kết quả thành công hoặc thất bại. Thao tác không thực hiện chuyển tiền thật.'),
('08-paid','Giao diện sau thanh toán','Giao dịch thành công làm xuất hiện trạng thái đã thanh toán. Tổng tiền giữ theo đơn lưu; thao tác thành công không được ghi nhận lặp.'),
('09-history','Giao diện lịch sử đơn hàng','Hiển thị đơn của tài khoản đang đăng nhập, mới trước. Chi tiết mở nội dung món, thông tin nhận và trạng thái thanh toán.'),
('10-profile','Giao diện thông tin tài khoản','Hiển thị họ tên, email, điện thoại và tên đăng nhập. Nút Đổi mật khẩu yêu cầu xác thực mật khẩu hiện tại.'),
('11-password','Giao diện đổi mật khẩu','Nhập mật khẩu hiện tại, mật khẩu mới và xác nhận. Sau kiểm tra, chương trình sinh salt mới và lưu giá trị dẫn xuất.'),
('12-admin','Giao diện chính quản trị viên','Thanh bên trái chứa các nhóm quản lý. Trang chính hiển thị số món, số đơn và tổng tiền đã thu.'),
('13-customers','Giao diện danh sách khách hàng','Ô tìm kiếm lọc theo tên. Bảng hiển thị thông tin liên hệ, không hiển thị mật khẩu hoặc giá trị dẫn xuất.'),
('14-foods','Giao diện quản lý món ăn','Tìm tên, sắp xếp giá hoặc tên, sửa món và thay trạng thái bán. Ngừng bán giữ lại món để bảo toàn tham chiếu lịch sử.'),
('15-edit','Giao diện chỉnh sửa món ăn','Biểu mẫu điền sẵn tên, danh mục, giá và mô tả. Chỉ lưu khi dữ liệu hợp lệ. Thay giá không làm đổi đơn giá trong đơn cũ.'),
('16-add','Giao diện thêm món ăn','Biểu mẫu trống tạo món mới. Mã cấp tự động; món mới mặc định đang bán. Có thể ngừng bán từ danh sách.'),
('17-discount','Giao diện tạo mã giảm giá','Nhập mã, mức giảm và lượt sử dụng. Mã mẫu hiển thị bên dưới. Mã trùng hoặc giá trị không hợp lệ bị từ chối.'),
('18-orders','Giao diện quản lý đơn hàng','Quản trị xem đơn của các khách, mở chi tiết để nhận tiền, tiếp nhận hoặc chuyển trạng thái. Quyền được kiểm tra tại Store.'),
('19-revenue','Giao diện thống kê tiền đã thu','Tổng và biểu đồ chỉ tính giao dịch thành công. Các ngày có giao dịch được nhóm và hiển thị tối đa bảy cột gần nhất.'),
('20-complete','Giao diện đơn hoàn thành','Đơn hoàn thành sau thanh toán và quá trình xử lý. Trạng thái kết thúc không còn nút chuyển tiếp hoặc trả tiền lại.')]
for j in range(0,len(screens),2):
    blocks=[h('5.2.1. Giao diện khách hàng' if j<10 else '5.2.2. Giao diện quản trị và tài khoản')]
    for k in range(j,j+2):
        name,title,desc=screens[k]
        blocks += [h(f'{k+1}. {title}'),p(desc),fig('screenshots/'+name+'.png',f'Hình 5.2-{k+1}. {title}')]
    page('5. CHƯƠNG TRÌNH VÀ KẾT QUẢ',*blocks)
page('5. CHƯƠNG TRÌNH VÀ KẾT QUẢ',
h('5.3. Kiểm thử chương trình'),
p('tests/test_core.cpp tạo tệp riêng cho từng lần chạy và gọi trực tiếp Store. Kết quả ghi nhận 31 kiểm tra đạt. Các kiểm tra tập trung nghiệp vụ và lưu trữ, không phải kiểm thử tải, kiểm định an toàn hoặc mọi tổ hợp thao tác giao diện.'),
table(['Nhóm','Nội dung đã kiểm tra'],[['Tài khoản','Đăng nhập, sai mật khẩu, tên trùng, thông tin sai, đổi mật khẩu.'],['Đặt món','Giỏ rỗng; số lượng 0 hoặc quá 99; ngừng bán; thiếu người nhận.'],['Tính tiền','Mã giảm không tồn tại; tổng và tiền giảm đúng.'],['Lịch sử','Đổi giá thực đơn không đổi đơn giá lịch sử.'],['Phân quyền','Khách khác không xem đơn; không sửa món hoặc xác nhận tiền mặt.'],['Thanh toán','Thất bại không cộng; thành công cộng đúng; chặn thành công lặp.'],['Trạng thái','Chặn hủy đơn trả tiền, hoàn thành chưa trả, chuyển trạng thái cuối.'],['Lưu trữ','Đọc lại; báo lỗi ghi; phục hồi bộ nhớ; từ chối tệp thiếu.']]),
p('Hình giao diện được kết xuất bằng cùng hàm draw của ứng dụng, với dữ liệu trình diễn tách khỏi data dùng khi chạy thông thường. Việc này kiểm tra bố trí và nội dung mà không đưa dữ liệu thử vào bản sử dụng.'))
page('5. CHƯƠNG TRÌNH VÀ KẾT QUẢ',
h('5.3.1. Một số kết quả cụ thể'),
table(['Tình huống','Kết quả mong đợi','Thực tế'],[['Giỏ rỗng','Không tạo đơn','Đạt'],['Món ngừng bán','Báo lỗi khi đặt','Đạt'],['Hai cơm gà + trà, HAI10','105.000 đồng','Đạt'],['Đổi giá cơm gà 99.000','Đơn cũ giữ 45.000','Đạt'],['Thanh toán thất bại','Tiền đã thu bằng 0','Đạt'],['Lặp mã thành công','Không cộng lần hai','Đạt'],['Khách xác nhận tiền mặt','Bị từ chối','Đạt'],['Hoàn thành chưa trả','Bị từ chối','Đạt'],['Hủy đơn hợp lệ','Hoàn lượt mã','Đạt'],['Ghi tệp lỗi','Phục hồi giá trước sửa','Đạt']]),
h('5.4. Nhận xét và đánh giá'),
p('Chương trình thực hiện luồng đặt món, thanh toán và xử lý đơn của một cửa hàng cục bộ. Phần nghiệp vụ và giao diện tách nhau để dễ đọc, kiểm tra và sửa. Đóng, mở lại vẫn giữ đơn đã tạo.'),
p('Các kiểm tra xác nhận tình huống đã nêu, không khẳng định ứng dụng không còn lỗi trong mọi điều kiện. Giao diện cố định, tìm tên tiếng Việt và dữ liệu lớn cần mở rộng kiểm thử.'))
page('6. KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN',
h('6.1. Kết luận'),h('6.1.1. Kết quả đạt được'),
p('Đề tài đã xây dựng ứng dụng C++ có giao diện đồ họa phục vụ đặt món và thanh toán tại một cửa hàng. Khách tạo tài khoản, đăng nhập, chọn món, quản lý giỏ, đặt đơn và xem lịch sử. Quản trị quản lý thực đơn, mã giảm, đơn và tiền đã thu.'),
p('Tách đơn khỏi thanh toán biểu diễn được chưa trả, thử thất bại và thành công. Tên và giá lưu cùng chi tiết đơn bảo toàn lịch sử khi thực đơn thay đổi. Phương thức nghiệp vụ kiểm tra vai trò và quyền trước cập nhật.'),
p('Chương trình dùng vector, map, tìm kiếm tuyến tính, sắp xếp, tệp và ngoại lệ. Store và FileManager phân tách trách nhiệm, đóng gói dữ liệu. Bộ kiểm thử ghi nhận 31 kiểm tra đạt trong môi trường thực hiện.'),
h('6.1.2. Những hạn chế'),
li('Chạy cục bộ một tiến trình; chưa có máy chủ hoặc đồng bộ nhiều máy.','Thanh toán điện tử mô phỏng; chưa có ngân hàng và hoàn tiền.','Giỏ chưa đặt không lưu sau đóng hoặc đăng xuất.','Chưa khôi phục mật khẩu email, giao hàng và quản lý nguyên liệu.','Giao diện cố định; hình món minh họa; chưa tìm tên không dấu.'))
page('6. KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN',
h('6.2. Hướng phát triển'),
p('Hướng đầu tiên là thay lưu trữ tệp bằng cơ sở dữ liệu có giao dịch, hỗ trợ quan hệ, ràng buộc và cập nhật một phần dữ liệu. Khi mở rộng nhiều máy, cần máy chủ xác thực yêu cầu và xử lý đồng thời.'),
p('Hướng thứ hai là thanh toán trực tuyến. Thành công phải dựa trên thông báo xác thực từ nhà cung cấp, đối chiếu số tiền và mã đơn. Cần hoàn tiền, đối soát và xử lý hủy sau thanh toán.'),
p('Hướng thứ ba là trải nghiệm: tìm tiếng Việt không dấu, giao diện co giãn, ảnh thực tế, ghi chú từng món và lưu giỏ giữa các phiên. Thêm quản lý danh mục riêng để tránh tên danh mục không thống nhất.'),
p('Quản lý có thể mở rộng sang số suất còn lại, nguyên liệu, khuyến mãi có thời hạn và món bán chạy. Cần xác định điểm giữ suất và hoàn suất trong đặt/hủy để không nhận quá khả năng phục vụ.'),
p('Trước sử dụng thực tế cần kiểm thử tải, quyền truy cập, mất kết nối hoặc mất điện và tổ chức sao lưu. Phiên bản hiện tại phục vụ học tập, trình diễn và làm nền phát triển.'))
page('TÀI LIỆU THAM KHẢO',
p('[1] Lương Văn Võ, Nguyễn Hiếu. Báo cáo PBL2: Hệ thống mua bán và quản lý thiết bị điện tử. Đại học Bách khoa, Đại học Đà Nẵng, 01/2025. PDF do người học cung cấp; tham khảo bố cục và bố trí giao diện.'),
p('[2] Microsoft Learn. Classes (GDI+). https://learn.microsoft.com/en-us/windows/win32/gdiplus/-gdiplus-class-classes. Truy cập ngày 21/10/2026.'),
p('[3] Microsoft Learn. BCryptDeriveKeyPBKDF2 function (bcrypt.h). https://learn.microsoft.com/en-us/windows/win32/api/bcrypt/nf-bcrypt-bcryptderivekeypbkdf2. Truy cập ngày 21/10/2026.'),
p('[4] Microsoft Learn. MoveFileExW function (winbase.h). https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-movefileexw. Truy cập ngày 21/10/2026.'),
p('[5] Mã nguồn kèm báo cáo: src/core.hpp, src/main.cpp, tests/test_core.cpp và tests/results.txt. Các mô tả chức năng, dữ liệu và kiểm thử đối chiếu phiên bản bàn giao.'))
(ROOT/'report'/'content.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2),encoding='utf-8')
print('Content pages:',len(pages))
