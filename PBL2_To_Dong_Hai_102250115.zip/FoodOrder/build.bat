@echo off
setlocal
cd /d "%~dp0"
if not defined CXX set "CXX=g++"
where "%CXX%" >nul 2>nul
if errorlevel 1 if exist "C:\msys64\ucrt64\bin\g++.exe" set "CXX=C:\msys64\ucrt64\bin\g++.exe"
"%CXX%" -std=c++17 -O2 -Wall -Wextra -municode -mwindows -static -static-libgcc -static-libstdc++ src\main.cpp -o FoodOrder.exe -lgdiplus -lbcrypt -lgdi32 -luser32
if errorlevel 1 (
  echo Build failed. Install MinGW-w64 g++ or set CXX to its absolute path.
  exit /b 1
)
echo Build successful: FoodOrder.exe
