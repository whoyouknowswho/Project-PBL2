# Ứng dụng đặt món ăn và thanh toán đơn hàng

**Sinh viên:** Tô Đông Hải — 102250115  
**Giảng viên hướng dẫn:** Trương Ngọc Châu

## Chạy nhanh

1. Giải nén toàn bộ gói ZIP vào một thư mục có quyền ghi.
2. Mở `FoodOrder.exe` hoặc `run.bat` trên Windows 10/11 64-bit.
3. Đăng nhập bằng tài khoản bên dưới hoặc đăng ký tài khoản mới.

| Vai trò | Tên đăng nhập | Mật khẩu mẫu |
|---|---|---|
| Khách hàng | `khach` | `Khach@123` |
| Quản trị viên | `admin` | `Admin@123` |

Lần chạy đầu tạo `data/store.txt`. Đây là dữ liệu mẫu để học tập. Đổi mật khẩu trước khi dùng dữ liệu cá nhân; sao lưu thư mục `data` trước khi chuyển máy. Không chỉnh sửa tệp khi chương trình đang chạy.

## Công nghệ và giao diện

- C++17, giao diện Win32/GDI+, Windows CNG để dẫn xuất mật khẩu.
- Giao diện tham khảo nền vàng nhạt, lưới 4 cột, nút đỏ, giỏ hai cột và thanh quản trị của báo cáo mẫu.
- Bản này **không dùng SFML**; có file thực thi không cần cài thư viện đồ họa bên ngoài.
- Hình món ăn là minh họa được vẽ trong mã nguồn, không phải ảnh chụp món thật.
- Nhận món tại cửa hàng. Thanh toán tiền mặt hoặc **mô phỏng**, không kết nối ngân hàng.

## Các chức năng

Khách: đăng ký, đăng nhập, đổi mật khẩu, tìm/lọc món, xem chi tiết, quản lý giỏ, đặt đơn có ghi chú, mã giảm giá, thanh toán mô phỏng và xem lịch sử.

Quản trị: xem/tìm khách; thêm/sửa/ngừng bán món; tìm/sắp xếp món; tạo mã giảm; xử lý đơn; xác nhận thu tiền mặt; biểu đồ tiền đã thu.

Đơn đi theo: chờ xác nhận → đã xác nhận → đang chế biến → sẵn sàng nhận → hoàn thành. Chỉ hoàn thành sau khi thanh toán. Chỉ hủy khi còn chờ và chưa thanh toán. Hủy hợp lệ hoàn lượt mã giảm.

## Trình diễn trong 5 phút

1. Vào `khach`, thêm 2 cơm gà, 1 gỏi cuốn và 2 trà đào.
2. Mở giỏ: tổng 170.000 đồng.
3. Thanh toán, nhập `HAI10` (giảm 10.000 đồng), chọn mô phỏng, đặt đơn.
4. Đơn 160.000 đồng: thử thất bại rồi thành công.
5. Vào lịch sử để xem lại đơn.
6. Đăng xuất, vào `admin`, mở Đơn hàng → Chi tiết và chuyển đến hoàn thành.
7. Thử đơn tiền mặt: khách không có nút xác nhận thu; quản trị mới được xác nhận.

## Biên dịch

Đã kiểm tra bằng MinGW-w64 UCRT g++ 16.1.0 trên Windows. Chạy `build.bat`. Script tìm `g++` trong PATH hoặc đường dẫn MSYS2 `C:\msys64\ucrt64\bin\g++.exe`.

Có thể đặt biến `CXX` thành đường dẫn đến trình biên dịch. Lệnh tương đương:

```bat
g++ -std=c++17 -O2 -Wall -Wextra -municode -mwindows -static -static-libgcc -static-libstdc++ src/main.cpp -o FoodOrder.exe -lgdiplus -lbcrypt -lgdi32 -luser32
```

Có cấu hình CMake bổ sung; đường biên dịch đã chạy kiểm tra là `build.bat` với MinGW, chưa xác nhận trên MSVC.

## Cấu trúc mã nguồn

| Tệp | Nội dung |
|---|---|
| `src/core.hpp` | Các thực thể, FileManager và Store; độc lập với giao diện |
| `src/main.cpp` | Win32, ô nhập, vẽ GDI+, điều hướng và xử lý chuột |
| `tests/test_core.cpp` | 31 kiểm tra nghiệp vụ và lưu trữ |
| `tests/results.txt` | Kết quả kiểm thử nghiệp vụ |
| `tests/ui-results.txt` | 10 kiểm tra nút/điều hướng qua sự kiện cửa sổ |
| `report/Bao_cao_PBL2_To_Dong_Hai.docx` | Báo cáo Word chỉnh sửa được |
| `report/Bao_cao_PBL2_To_Dong_Hai.pdf` | Báo cáo PDF để xem/in |

Đọc `core.hpp` trước để hiểu dữ liệu và quy tắc; sau đó đọc `go`, `draw` và `proc` trong `main.cpp` để hiểu giao diện. Tiền là số nguyên VND. Tên và đơn giá được chụp vào OrderItem khi đặt. Payment lưu riêng và kiểm tra mã tham chiếu để tránh ghi nhận thành công lặp.

## Kiểm thử

Chạy `test.bat` sau khi biên dịch ứng dụng. Các ca tạo dữ liệu riêng, không thay đổi `data/store.txt`. Kết quả đã chạy: **31 kiểm tra nghiệp vụ + 10 kiểm tra sự kiện giao diện đạt**.

`FoodOrder.exe --screenshots` kết xuất 20 màn hình bằng cùng hàm vẽ của ứng dụng vào `report/screenshots`, dùng dữ liệu QA riêng. `FoodOrder.exe --ui-test` kiểm tra chuỗi thao tác qua thông điệp cửa sổ ẩn.

## Báo cáo

Báo cáo giữ bìa khung đôi, Times New Roman, mục lục, danh mục hình, đầu/chân trang và 6 chương như tài liệu tham khảo. Nội dung và hình chuyển sang ứng dụng món ăn. Bản bàn giao có 44 trang; lớp và nhóm để trống cho sinh viên điền.

Mục lục và danh mục hình là bản tĩnh đã đối chiếu PDF. Nếu thay đổi nội dung làm đổi số trang, cần cập nhật mục lục. `report/content.py` và `report/build_report.py` là script tạo lại DOCX; cần Python với python-docx và Pillow, font Windows và các hình trong gói. Việc xuất PDF được thực hiện bằng Word.

## Giới hạn hiện tại

Ứng dụng chạy cục bộ một tiến trình; giỏ chưa đặt mất khi đăng xuất/đóng; chưa có OTP email, giao hàng, hoàn tiền, quản lý nguyên liệu hoặc tìm không dấu. Danh mục mới nhập thủ công chỉ hiện trong Tất cả nếu khác 4 danh mục chuẩn. Dữ liệu tệp không mã hóa và không được bảo vệ trước người sửa trực tiếp. Kiểm thử hiện có không phải đánh giá tải hoặc chứng nhận sẵn sàng vận hành thực tế.
