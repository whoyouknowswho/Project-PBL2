#include "../src/core.hpp"
#include <iostream>
using namespace food;
int passed = 0;
void test(bool ok, const char *name) {
    if (!ok)
        throw std::runtime_error(name);
    std::cout << "PASS " << name << "\n";
    passed++;
}
void rejects(std::function<void()> f, const char *name) {
    bool threw = false;
    try {
        f();
    } catch (const std::exception &) {
        threw = true;
    }
    test(threw, name);
}
int main() {
    try {
        auto path = std::filesystem::path("tests") / ("run-" + std::to_string(GetTickCount64())) /
                    "store.txt";
        Store s(path);
        int admin = s.login("admin", "Admin@123"), user = s.login("khach", "Khach@123");
        test(admin == 1 && user == 2, "seed login");
        rejects([&] { s.login("khach", "wrong"); }, "invalid password");
        rejects([&] { s.registerUser("A", "a@b", "0901111111", "khach", "123456"); },
                "duplicate login");
        int other = s.registerUser("Test", "test@local", "0901111111", "test", "Test@123");
        rejects([&] { s.registerUser("A", "bad", "xx", "bad", "123456"); }, "invalid registration");
        s.changePassword(other, "Test@123", "Other@123");
        test(s.login("test", "Other@123") == other, "change password");
        rejects([&] { s.place(user, {}, "receiver", "", "", "cash"); }, "empty cart");
        rejects([&] { s.place(user, {{1, 0, ""}}, "receiver", "", "", "cash"); }, "zero quantity");
        rejects([&] { s.place(user, {{1, 100, ""}}, "receiver", "", "", "cash"); }, "quantity cap");
        rejects([&] { s.place(user, {{12, 1, ""}}, "receiver", "", "", "cash"); },
                "unavailable food");
        rejects([&] { s.place(user, {{1, 1, ""}}, "", "", "", "cash"); }, "missing receiver");
        rejects([&] { s.place(user, {{1, 1, ""}}, "R", "", "BAD", "cash"); }, "invalid discount");
        int id = s.place(user, {{1, 2, ""}, {7, 1, ""}}, "R", "note", "HAI10", "simulation");
        test(s.order(user, id).total == 105000, "order arithmetic and discount");
        auto f = s.food(1);
        f.price = 99000;
        s.saveFood(admin, f);
        test(s.order(user, id).items[0].price == 45000, "historical price snapshot");
        rejects([&] { s.order(other, id); }, "other customer order blocked");
        rejects([&] { s.saveFood(user, f); }, "admin authorization");
        s.pay(user, id, false, "fail");
        test(!s.paid(id) && s.revenue() == 0, "failed payment excluded");
        s.pay(user, id, true, "ok");
        test(s.paid(id) && s.revenue() == 105000, "successful payment");
        s.pay(user, id, true, "ok");
        test(s.revenue() == 105000, "idempotent callback");
        rejects([&] { s.pay(user, id, true, "ok2"); }, "second success blocked");
        rejects([&] { s.cancel(user, id); }, "paid cancellation blocked");
        for (int i = 0; i < 4; i++) {
            s.advance(admin, id);
        }
        test(s.order(user, id).status == 4, "complete paid order");
        rejects([&] { s.advance(admin, id); }, "terminal state protected");
        int cash = s.place(user, {{2, 1, ""}}, "R", "", "", "cash");
        rejects([&] { s.pay(user, cash, true, "cash-user"); }, "customer cannot confirm cash");
        for (int i = 0; i < 3; i++)
            s.advance(admin, cash);
        rejects([&] { s.advance(admin, cash); }, "unpaid completion blocked");
        s.pay(admin, cash, true, "cash-admin");
        s.advance(admin, cash);
        test(s.order(admin, cash).status == 4, "cash workflow");
        int cancelled = s.place(user, {{2, 1, ""}}, "R", "", "HAI10", "cash");
        s.cancel(user, cancelled);
        test(s.order(user, cancelled).status == 5 && s.data().discounts[0].remaining == 19,
             "cancel restores coupon");
        rejects([&] { s.pay(admin, cancelled, true, "cancel"); }, "cancelled payment blocked");
        Store restored(path);
        test(restored.revenue() == 155000 && restored.order(user, id).items[0].price == 45000,
             "persistence round trip");
        // A blocked temp path must roll back the in-memory mutation.
        auto tmp = path;
        tmp += L".tmp";
        std::filesystem::create_directory(tmp);
        auto oldPrice = restored.food(2).price;
        auto bad = restored.food(2);
        bad.price = 60000;
        rejects([&] { restored.saveFood(admin, bad); }, "save error reported");
        test(restored.food(2).price == oldPrice, "save failure rolls back");
        auto corrupt = path.parent_path() / "broken.txt";
        {
            std::ofstream f(corrupt);
            f << "FOODORDER 1\n";
        }
        rejects([&] { Store broken(corrupt); }, "truncated file rejected");
        std::cout << "TOTAL " << passed << " PASS\n";
        return 0;
    } catch (const std::exception &e) {
        std::cerr << "FAIL " << e.what() << "\n";
        return 1;
    }
}
