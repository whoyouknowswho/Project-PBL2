@echo off
setlocal
cd /d "%~dp0"
if not defined CXX set "CXX=g++"
where "%CXX%" >nul 2>nul
if errorlevel 1 if exist "C:\msys64\ucrt64\bin\g++.exe" set "CXX=C:\msys64\ucrt64\bin\g++.exe"
"%CXX%" -std=c++17 -O2 -Wall -Wextra -static -static-libgcc -static-libstdc++ tests\test_core.cpp -o tests\test_core.exe -lbcrypt
if errorlevel 1 exit /b 1
tests\test_core.exe > tests\results.txt
if errorlevel 1 (
  type tests\results.txt
  exit /b 1
)
type tests\results.txt
start "" /wait FoodOrder.exe --ui-test
if errorlevel 1 exit /b 1
type tests\ui-results.txt
