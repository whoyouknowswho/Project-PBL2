#pragma once
#define NOMINMAX
#include <windows.h>
#include <algorithm>
#include <bcrypt.h>
#include <cstdint>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace food {
using Money = long long;
inline void require(bool ok, const char *msg) {
    if (!ok)
        throw std::runtime_error(msg);
}
inline std::string now() {
    std::time_t t = std::time(nullptr);
    std::tm tm{};
    localtime_s(&tm, &t);
    char s[32];
    std::strftime(s, sizeof s, "%Y-%m-%d %H:%M:%S", &tm);
    return s;
}
inline std::string hex(const unsigned char *p, size_t n) {
    static const char *h = "0123456789abcdef";
    std::string s;
    for (size_t i = 0; i < n; i++) {
        s += h[p[i] >> 4];
        s += h[p[i] & 15];
    }
    return s;
}
inline std::string salt() {
    unsigned char b[16];
    require(BCryptGenRandom(nullptr, b, 16, BCRYPT_USE_SYSTEM_PREFERRED_RNG) >= 0,
            "Khong tao duoc salt");
    return hex(b, 16);
}
inline std::string hash(const std::string &pass, const std::string &saltValue) {
    BCRYPT_ALG_HANDLE a = nullptr;
    unsigned char out[32];
    require(BCryptOpenAlgorithmProvider(&a, BCRYPT_SHA256_ALGORITHM, nullptr,
                                        BCRYPT_ALG_HANDLE_HMAC_FLAG) >= 0,
            "Loi BCrypt");
    auto rc =
        BCryptDeriveKeyPBKDF2(a, (PUCHAR)pass.data(), (ULONG)pass.size(), (PUCHAR)saltValue.data(),
                              (ULONG)saltValue.size(), 100000, out, 32, 0);
    BCryptCloseAlgorithmProvider(a, 0);
    require(rc >= 0, "Loi bam mat khau");
    return hex(out, 32);
}
struct User {
    int id = 0;
    std::string name, email, phone, login, saltValue, digest;
    bool admin = false;
};
struct FoodItem {
    int id = 0;
    std::string name, category, description;
    Money price = 0;
    bool available = true;
    int art = 0;
};
struct CartItem {
    int foodId = 0, quantity = 1;
    std::string note;
};
struct OrderItem {
    int foodId = 0;
    std::string name;
    Money price = 0;
    int quantity = 0;
    std::string note;
    Money total() const {
        return price * quantity;
    }
};
struct Order {
    int id = 0, userId = 0;
    std::string created, receiver, note;
    std::vector<OrderItem> items;
    Money subtotal = 0, discount = 0, total = 0;
    std::string coupon;
    int status = 0;
}; // 0 pending, 1 confirmed, 2 cooking, 3 ready, 4 completed, 5 cancelled
struct Payment {
    int id = 0, orderId = 0;
    std::string method, created, reference;
    Money amount = 0;
    int status = 0;
}; // 0 pending, 1 success, 2 failed
struct Discount {
    std::string code;
    Money amount = 0;
    int remaining = 0;
};
struct State {
    std::vector<User> users;
    std::vector<FoodItem> foods;
    std::vector<Order> orders;
    std::vector<Payment> payments;
    std::vector<Discount> discounts;
    int nextUser = 1, nextFood = 1, nextOrder = 1, nextPayment = 1;
};
class FileManager {
    std::filesystem::path path;

  public:
    explicit FileManager(std::filesystem::path p) : path(std::move(p)) {}
    bool exists() const {
        return std::filesystem::exists(path);
    }
    void save(const State &s) {
        if (!path.parent_path().empty())
            std::filesystem::create_directories(path.parent_path());
        auto temp = path;
        temp += L".tmp";
        std::ofstream f(temp, std::ios::binary | std::ios::trunc);
        require(bool(f), "Khong mo duoc tep du lieu");
        f << "FOODORDER 1\n"
          << s.nextUser << ' ' << s.nextFood << ' ' << s.nextOrder << ' ' << s.nextPayment << '\n';
        f << s.users.size() << '\n';
        for (auto &u : s.users)
            f << u.id << ' ' << std::quoted(u.name) << ' ' << std::quoted(u.email) << ' '
              << std::quoted(u.phone) << ' ' << std::quoted(u.login) << ' '
              << std::quoted(u.saltValue) << ' ' << std::quoted(u.digest) << ' ' << u.admin << '\n';
        f << s.foods.size() << '\n';
        for (auto &x : s.foods)
            f << x.id << ' ' << std::quoted(x.name) << ' ' << std::quoted(x.category) << ' '
              << std::quoted(x.description) << ' ' << x.price << ' ' << x.available << ' ' << x.art
              << '\n';
        f << s.orders.size() << '\n';
        for (auto &o : s.orders) {
            f << o.id << ' ' << o.userId << ' ' << std::quoted(o.created) << ' '
              << std::quoted(o.receiver) << ' ' << std::quoted(o.note) << ' ' << o.subtotal << ' '
              << o.discount << ' ' << o.total << ' ' << std::quoted(o.coupon) << ' ' << o.status
              << ' ' << o.items.size() << '\n';
            for (auto &i : o.items)
                f << i.foodId << ' ' << std::quoted(i.name) << ' ' << i.price << ' ' << i.quantity
                  << ' ' << std::quoted(i.note) << '\n';
        }
        f << s.payments.size() << '\n';
        for (auto &p : s.payments)
            f << p.id << ' ' << p.orderId << ' ' << std::quoted(p.method) << ' '
              << std::quoted(p.created) << ' ' << std::quoted(p.reference) << ' ' << p.amount << ' '
              << p.status << '\n';
        f << s.discounts.size() << '\n';
        for (auto &d : s.discounts)
            f << std::quoted(d.code) << ' ' << d.amount << ' ' << d.remaining << '\n';
        f.flush();
        require(bool(f), "Ghi tep that bai");
        f.close();
        require(!f.fail(), "Dong tep that bai");
        require(MoveFileExW(temp.c_str(), path.c_str(),
                            MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0,
                "Khong thay the duoc tep du lieu");
    }
    State load() {
        State s;
        std::ifstream f(path, std::ios::binary);
        std::string magic;
        int version;
        f >> magic >> version;
        require(magic == "FOODORDER" && version == 1, "Dinh dang du lieu khong hop le");
        f >> s.nextUser >> s.nextFood >> s.nextOrder >> s.nextPayment;
        auto count = [&]() {
            size_t n = 0;
            f >> n;
            require(bool(f) && n < 100000, "Du lieu bi hong");
            return n;
        };
        for (size_t n = count(); n--;) {
            User u;
            f >> u.id >> std::quoted(u.name) >> std::quoted(u.email) >> std::quoted(u.phone) >>
                std::quoted(u.login) >> std::quoted(u.saltValue) >> std::quoted(u.digest) >>
                u.admin;
            require(u.digest.size() == 64 && u.saltValue.size() == 32,
                    "Du lieu mat khau khong hop le");
            s.users.push_back(u);
        }
        for (size_t n = count(); n--;) {
            FoodItem x;
            f >> x.id >> std::quoted(x.name) >> std::quoted(x.category) >>
                std::quoted(x.description) >> x.price >> x.available >> x.art;
            require(x.price > 0 && x.price <= 10000000, "Gia mon khong hop le");
            s.foods.push_back(x);
        }
        for (size_t n = count(); n--;) {
            Order o;
            f >> o.id >> o.userId >> std::quoted(o.created) >> std::quoted(o.receiver) >>
                std::quoted(o.note) >> o.subtotal >> o.discount >> o.total >>
                std::quoted(o.coupon) >> o.status;
            for (size_t m = count(); m--;) {
                OrderItem i;
                f >> i.foodId >> std::quoted(i.name) >> i.price >> i.quantity >>
                    std::quoted(i.note);
                o.items.push_back(i);
            }
            s.orders.push_back(o);
        }
        for (size_t n = count(); n--;) {
            Payment p;
            f >> p.id >> p.orderId >> std::quoted(p.method) >> std::quoted(p.created) >>
                std::quoted(p.reference) >> p.amount >> p.status;
            s.payments.push_back(p);
        }
        for (size_t n = count(); n--;) {
            Discount d;
            f >> std::quoted(d.code) >> d.amount >> d.remaining;
            s.discounts.push_back(d);
        }
        require(bool(f), "Du lieu bi cat ngan");
        return s;
    }
};
class Store {
    State s;
    FileManager files;
    void commit(const std::function<void()> &fn) {
        auto backup = s;
        try {
            fn();
            files.save(s);
        } catch (...) {
            s = std::move(backup);
            throw;
        }
    }
    void admin(int actor) const {
        require(user(actor).admin, "Chi quan tri vien duoc thao tac");
    }
    Order &mutableOrder(int id) {
        for (auto &o : s.orders)
            if (o.id == id)
                return o;
        throw std::runtime_error("Khong tim thay don");
    }

  public:
    explicit Store(const std::filesystem::path &p) : files(p) {
        if (files.exists())
            s = files.load();
        else
            seed();
    }
    const State &data() const {
        return s;
    }
    const User &user(int id) const {
        for (auto &u : s.users)
            if (u.id == id)
                return u;
        throw std::runtime_error("Khong tim thay tai khoan");
    }
    const FoodItem &food(int id) const {
        for (auto &x : s.foods)
            if (x.id == id)
                return x;
        throw std::runtime_error("Khong tim thay mon");
    }
    const Order &order(int actor, int id) const {
        for (auto &o : s.orders)
            if (o.id == id) {
                require(user(actor).admin || o.userId == actor, "Khong co quyen xem don");
                return o;
            }
        throw std::runtime_error("Khong tim thay don");
    }
    int login(const std::string &name, const std::string &pass) const {
        for (auto &u : s.users)
            if (u.login == name) {
                auto d = hash(pass, u.saltValue);
                unsigned char diff = 0;
                for (size_t i = 0; i < d.size(); i++)
                    diff |= d[i] ^ u.digest[i];
                if (!diff)
                    return u.id;
            }
        throw std::runtime_error("Sai ten dang nhap hoac mat khau");
    }
    int registerUser(std::string name, std::string email, std::string phone, std::string loginName,
                     std::string pass) {
        require(!name.empty() && !loginName.empty() && pass.size() >= 6,
                "Nhap ho ten, ten dang nhap va mat khau tu 6 ky tu");
        require(name.size() <= 200 && loginName.size() <= 80 && pass.size() <= 200,
                "Thong tin qua dai");
        require(email.find('@') != std::string::npos && phone.size() >= 9 && phone.size() <= 12 &&
                    std::all_of(phone.begin(), phone.end(),
                                [](char c) { return c >= '0' && c <= '9'; }),
                "Email hoac so dien thoai khong hop le");
        for (auto &u : s.users)
            require(u.login != loginName, "Ten dang nhap da ton tai");
        int id = s.nextUser;
        commit([&] {
            User u;
            u.id = s.nextUser++;
            u.name = name;
            u.email = email;
            u.phone = phone;
            u.login = loginName;
            u.saltValue = salt();
            u.digest = hash(pass, u.saltValue);
            require(u.digest.size() == 64 && u.saltValue.size() == 32,
                    "Du lieu mat khau khong hop le");
            s.users.push_back(u);
        });
        return id;
    }
    void changePassword(int actor, const std::string &oldPass, const std::string &pass) {
        auto u = user(actor);
        require(hash(oldPass, u.saltValue) == u.digest, "Mat khau hien tai khong dung");
        require(pass.size() >= 6 && pass.size() <= 200, "Mat khau phai tu 6 den 200 ky tu");
        commit([&] {
            for (auto &v : s.users)
                if (v.id == actor) {
                    v.saltValue = salt();
                    v.digest = hash(pass, v.saltValue);
                }
        });
    }
    void saveFood(int actor, FoodItem f) {
        admin(actor);
        require(!f.name.empty() && !f.category.empty() && f.price > 0 && f.price <= 10000000,
                "Ten, danh muc va gia mon khong hop le");
        commit([&] {
            if (f.id == 0) {
                f.id = s.nextFood++;
                s.foods.push_back(f);
            } else {
                bool found = false;
                for (auto &v : s.foods)
                    if (v.id == f.id) {
                        v = f;
                        found = true;
                    }
                require(found, "Khong tim thay mon");
            }
        });
    }
    void toggleFood(int actor, int id) {
        auto f = food(id);
        f.available = !f.available;
        saveFood(actor, f);
    }
    Money discountFor(const std::string &code, Money subtotal) const {
        if (code.empty())
            return 0;
        for (auto &d : s.discounts)
            if (d.code == code) {
                require(d.remaining > 0, "Ma giam gia da het luot");
                return std::min(d.amount, subtotal);
            }
        throw std::runtime_error("Ma giam gia khong ton tai");
    }
    void createDiscount(int actor, std::string code, Money amount, int count) {
        admin(actor);
        require(!code.empty() && amount > 0 && amount <= 10000000 && count > 0 && count <= 100000,
                "Ma, so tien hoac so luot khong hop le");
        for (auto &d : s.discounts)
            require(d.code != code, "Ma giam gia da ton tai");
        commit([&] { s.discounts.push_back({code, amount, count}); });
    }
    bool paid(int id) const {
        for (auto &p : s.payments)
            if (p.orderId == id && p.status == 1)
                return true;
        return false;
    }
    int place(int actor, const std::vector<CartItem> &cart, std::string receiver, std::string note,
              std::string coupon, std::string method) {
        user(actor);
        require(!cart.empty(), "Gio hang trong");
        require(!receiver.empty(), "Nhap thong tin nhan mon");
        require(method == "cash" || method == "simulation", "Phuong thuc khong hop le");
        Order o;
        o.id = s.nextOrder;
        o.userId = actor;
        o.created = now();
        o.receiver = receiver;
        o.note = note;
        o.coupon = coupon;
        int quantity = 0;
        for (auto &c : cart) {
            auto f = food(c.foodId);
            require(f.available, "Co mon da ngung ban, vui long cap nhat gio");
            require(c.quantity > 0 && c.quantity <= 99, "So luong phai tu 1 den 99");
            quantity += c.quantity;
            require(quantity <= 500, "Moi don toi da 500 suat");
            o.items.push_back({f.id, f.name, f.price, c.quantity, c.note});
            o.subtotal += f.price * c.quantity;
        }
        o.discount = discountFor(coupon, o.subtotal);
        o.total = o.subtotal - o.discount;
        commit([&] {
            s.nextOrder++;
            s.orders.push_back(o);
            if (!coupon.empty())
                for (auto &d : s.discounts)
                    if (d.code == coupon)
                        d.remaining--;
            s.payments.push_back({s.nextPayment++, o.id, method, now(), "", o.total, 0});
        });
        return o.id;
    }
    void pay(int actor, int id, bool success, const std::string &key) {
        auto o = order(actor, id);
        require(o.status != 5, "Don da huy");
        require(!key.empty(), "Ma tham chieu rong");
        // Replayed successful callbacks are idempotent.
        for (auto &p : s.payments)
            if (p.reference == key) {
                require(p.orderId == id, "Ma giao dich da dung cho don khac");
                return;
            }
        require(!paid(id), "Don da thanh toan");
        std::string method;
        for (auto &p : s.payments)
            if (p.orderId == id)
                method = p.method;
        require(method == "simulation" || user(actor).admin, "Tien mat can quan tri vien xac nhan");
        commit([&] {
            Payment *pending = nullptr;
            for (auto &p : s.payments)
                if (p.orderId == id && p.status == 0)
                    pending = &p;
            if (!pending) {
                s.payments.push_back({s.nextPayment++, id, method, now(), "", o.total, 0});
                pending = &s.payments.back();
            }
            pending->reference = key;
            pending->created = now();
            pending->status = success ? 1 : 2;
        });
    }
    void advance(int actor, int id) {
        admin(actor);
        auto o = order(actor, id);
        require(o.status >= 0 && o.status < 4, "Don khong the chuyen tiep");
        if (o.status == 3)
            require(paid(id), "Can thanh toan truoc khi hoan thanh");
        commit([&] { mutableOrder(id).status++; });
    }
    void cancel(int actor, int id) {
        auto o = order(actor, id);
        require(o.status == 0 && !paid(id), "Chi huy don cho xac nhan va chua thanh toan");
        commit([&] {
            mutableOrder(id).status = 5;
            for (auto &p : s.payments)
                if (p.orderId == id && p.status == 0)
                    p.status = 2;
            if (!o.coupon.empty())
                for (auto &d : s.discounts)
                    if (d.code == o.coupon)
                        d.remaining++;
        });
    }
    Money revenue(const std::string &day = "") const {
        Money total = 0;
        for (auto &p : s.payments)
            if (p.status == 1 && (day.empty() || p.created.substr(0, 10) == day))
                total += p.amount;
        return total;
    }
    void seed() {
        User a{1, "Quản trị viên", "admin@food.local", "0900000000", "admin", salt(), "", true};
        a.digest = hash("Admin@123", a.saltValue);
        User u{2, "Tô Đông Hải", "hai@food.local", "0901234567", "khach", salt(), "", false};
        u.digest = hash("Khach@123", u.saltValue);
        s.users = {a, u};
        s.nextUser = 3;
        s.foods = {
            {1, "Cơm gà Hội An", "Món chính", "Cơm vàng, gà xé, rau răm và nước mắm gừng.", 45000,
             true, 0},
            {2, "Bún bò Huế", "Món chính", "Bún, thịt bò, chả và nước dùng sả thơm.", 50000, true,
             1},
            {3, "Mì Quảng tôm thịt", "Món chính", "Mì Quảng với tôm, thịt, trứng và bánh tráng.",
             45000, true, 2},
            {4, "Phở bò tái", "Món chính", "Bánh phở, bò tái, hành và nước dùng nóng.", 50000, true,
             3},
            {5, "Gỏi cuốn tôm", "Món phụ", "Ba cuốn tôm, bún, rau sống, kèm sốt đậu phộng.", 30000,
             true, 4},
            {6, "Khoai tây chiên", "Món phụ", "Khoai tây chiên giòn, dùng kèm tương cà.", 25000,
             true, 5},
            {7, "Trà đào cam sả", "Đồ uống", "Trà đào mát lạnh với cam và sả.", 25000, true, 6},
            {8, "Nước cam tươi", "Đồ uống", "Cam vắt tươi, có thể ghi chú giảm đường.", 30000, true,
             7},
            {9, "Bánh flan", "Tráng miệng", "Bánh flan trứng sữa với lớp caramel.", 20000, true, 8},
            {10, "Chè đậu xanh", "Tráng miệng", "Chè đậu xanh nước cốt dừa.", 20000, true, 9},
            {11, "Cơm sườn nướng", "Món chính", "Cơm trắng, sườn nướng, dưa leo và nước mắm.",
             55000, true, 10},
            {12, "Sữa chua trái cây", "Tráng miệng", "Sữa chua với trái cây theo mùa.", 25000,
             false, 11}};
        s.nextFood = 13;
        s.discounts = {{"HAI10", 10000, 20}, {"PBL2", 15000, 10}};
        files.save(s);
    }
};
} // namespace food
