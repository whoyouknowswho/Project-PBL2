#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#include "core.hpp"
#include <cmath>
#include <gdiplus.h>
#include <map>
#include <memory>
using namespace food;
using namespace Gdiplus;
std::wstring w(const std::string &s) {
    if (s.empty())
        return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring r(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), r.data(), n);
    return r;
}
std::string u8(const std::wstring &s) {
    if (s.empty())
        return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0, nullptr, nullptr);
    std::string r(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), r.data(), n, nullptr, nullptr);
    return r;
}
std::wstring money(Money n) {
    std::wstring s = std::to_wstring(n);
    for (int i = (int)s.size() - 3; i > 0; i -= 3)
        s.insert(i, L".");
    return s + L" đ";
}
std::wstring statusName(int n) {
    static const wchar_t *s[] = {L"Chờ xác nhận",  L"Đã xác nhận", L"Đang chế biến",
                                 L"Sẵn sàng nhận", L"Hoàn thành",  L"Đã hủy"};
    return s[std::clamp(n, 0, 5)];
}
enum Screen {
    Login,
    Register,
    Menu,
    Detail,
    Cart,
    Checkout,
    History,
    OrderDetail,
    Profile,
    Password,
    AdminHome,
    Customers,
    Foods,
    EditFood,
    Discounts,
    Revenue,
    Orders,
    Help
};
struct Button {
    RECT r;
    std::function<void()> action;
};
struct Field {
    int id, x, y, width, height;
    std::wstring label;
    HWND hwnd;
    bool password;
};
HWND windowHandle = nullptr;
HFONT editFont = nullptr;
std::unique_ptr<Store> store;
int actor = 0, selectedFood = 1, selectedOrder = 0, editingFood = 0, page = 0, sortMode = 0;
Screen screen = Login;
std::wstring category = L"Tất cả", query, message;
std::string method = "cash";
std::vector<CartItem> cart;
std::vector<Button> buttons;
std::vector<Field> fields;
std::filesystem::path base;
bool exportMode = false;
Color bg(247, 246, 222), red(255, 55, 50), ink(30, 30, 30), gray(120, 120, 110);
void go(Screen s);
void refresh() {
    InvalidateRect(windowHandle, nullptr, FALSE);
}
std::wstring value(int id) {
    for (auto &f : fields)
        if (f.id == id) {
            int n = GetWindowTextLengthW(f.hwnd);
            std::wstring s(n + 1, 0);
            GetWindowTextW(f.hwnd, s.data(), n + 1);
            s.resize(n);
            return s;
        }
    return L"";
}
void setValue(int id, const std::wstring &v) {
    for (auto &f : fields)
        if (f.id == id)
            SetWindowTextW(f.hwnd, v.c_str());
}
void field(int id, int x, int y, int width, const std::wstring &label,
           const std::wstring &initial = L"", bool password = false) {
    HWND h = CreateWindowExW(
        WS_EX_CLIENTEDGE, L"EDIT", initial.c_str(),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL | (password ? ES_PASSWORD : 0), x, y,
        width, 32, windowHandle, (HMENU)(INT_PTR)id, GetModuleHandle(nullptr), nullptr);
    SendMessageW(h, WM_SETFONT, (WPARAM)editFont, TRUE);
    SendMessageW(h, EM_SETLIMITTEXT, 200, 0);
    fields.push_back({id, x, y, width, 32, label, h, password});
}
long long number(int id) {
    auto s = u8(value(id));
    size_t n = 0;
    long long v = std::stoll(s, &n);
    require(n == s.size(), "Vui long nhap so nguyen");
    return v;
}
void attempt(const std::function<void()> &f) {
    try {
        message.clear();
        f();
    } catch (const std::exception &e) {
        message = w(e.what());
        MessageBeep(MB_ICONWARNING);
    }
    refresh();
}
void text(Graphics &g, const std::wstring &s, float x, float y, float width = 900,
          float height = 30, int size = 16, Color color = ink, bool bold = false, int align = 0) {
    Font font(L"Arial", (REAL)size, bold ? FontStyleBold : FontStyleRegular, UnitPixel);
    SolidBrush b(color);
    StringFormat fmt;
    fmt.SetTrimming(StringTrimmingEllipsisCharacter);
    fmt.SetAlignment(align == 1   ? StringAlignmentCenter
                     : align == 2 ? StringAlignmentFar
                                  : StringAlignmentNear);
    g.DrawString(s.c_str(), -1, &font, RectF(x, y, width, height), &fmt, &b);
}
void box(Graphics &g, float x, float y, float width, float height, Color c, bool border = false) {
    SolidBrush b(c);
    g.FillRectangle(&b, x, y, width, height);
    if (border) {
        Pen p(Color(192, 192, 170));
        g.DrawRectangle(&p, x, y, width, height);
    }
}
void line(Graphics &g, float x, float y, float x2, float y2) {
    Pen p(Color(200, 200, 180));
    g.DrawLine(&p, x, y, x2, y2);
}
void button(Graphics &g, const std::wstring &label, int x, int y, int width, int height,
            std::function<void()> fn, int style = 0) {
    Color c = style == 1 ? red : style == 2 ? Color::Black : style == 3 ? Color(230, 235, 215) : bg;
    box(g, (float)x, (float)y, (float)width, (float)height, c, style == 0);
    text(g, label, (float)x + 4, (float)y + (height - 20) / 2, (float)width - 8, 25, 14,
         (style == 1 || style == 2) ? Color::White : ink, style == 1, 1);
    buttons.push_back({{x, y, x + width, y + height}, std::move(fn)});
}
void foodArt(Graphics &g, int art, float x, float y, float width, float height) {
    g.SetSmoothingMode(SmoothingModeAntiAlias);
    float cx = x + width / 2, cy = y + height / 2, r = std::min(width, height) * 0.39f;
    SolidBrush shadow(Color(236, 234, 225)), plate(Color::White), edge(Color(217, 224, 217)),
        yellow(Color(241, 190, 69)), brown(Color(157, 83, 35)), green(Color(68, 133, 59)),
        orange(Color(241, 133, 45)), light(Color(252, 227, 153));
    g.FillEllipse(&shadow, cx - r + 5, cy - r + 8, 2 * r, 2 * r);
    g.FillEllipse(&edge, cx - r, cy - r, 2 * r, 2 * r);
    g.FillEllipse(&plate, cx - r + 5, cy - r + 5, 2 * r - 10, 2 * r - 10);
    if (art == 6 || art == 7) {
        g.FillRectangle(&orange, cx - r * .52f, cy - r * .8f, r * 1.04f, r * 1.6f);
        Pen straw(Color(80, 110, 65), 4);
        g.DrawLine(&straw, cx + r * .2f, cy + r * .5f, cx + r * .4f, cy - r * 1.15f);
        g.FillEllipse(&yellow, cx - r * .7f, cy - r * .8f, r * .8f, r * .8f);
    } else if (art == 5) {
        for (int i = 0; i < 10; i++)
            g.FillRectangle(&yellow, cx - r * .65f + (i % 5) * r * .25f,
                            cy - r * .6f + (i / 5) * r * .5f, r * .16f, r * .85f);
    } else if (art == 4) {
        for (int i = 0; i < 3; i++) {
            g.FillRectangle(&light, cx - r * .75f, cy - r * .65f + i * r * .45f, r * 1.5f, r * .3f);
            g.FillEllipse(&orange, cx - r * .2f, cy - r * .65f + i * r * .45f, r * .35f, r * .25f);
        }
    } else if (art >= 8 && art != 10) {
        g.FillEllipse(&light, cx - r * .7f, cy - r * .6f, r * 1.4f, r * 1.2f);
        g.FillEllipse(&brown, cx - r * .6f, cy - r * .55f, r * 1.2f, r * .55f);
    } else {
        g.FillEllipse(&yellow, cx - r * .75f, cy - r * .75f, r * 1.5f, r * 1.5f);
        if (art == 1 || art == 2 || art == 3) {
            Pen noodle(Color(255, 242, 191), 3);
            for (int i = 0; i < 7; i++)
                g.DrawArc(&noodle, cx - r * .6f + i * 3, cy - r * .55f + i * 4, r * .95f, r * .85f,
                          20, 260);
        }
        for (int i = 0; i < 4; i++)
            g.FillEllipse(&brown, cx - r * .5f + (i % 2) * r * .45f,
                          cy - r * .4f + (i / 2) * r * .45f, r * .5f, r * .3f);
        for (int i = 0; i < 4; i++)
            g.FillEllipse(&green, cx + r * .25f, cy - r * .55f + i * r * .3f, r * .4f, r * .2f);
    }
}
void addCart(int id) {
    auto f = store->food(id);
    require(f.available, "Mon dang ngung ban");
    for (auto &c : cart)
        if (c.foodId == id) {
            require(c.quantity < 99, "Toi da 99 suat moi mon");
            c.quantity++;
            message = L"Đã tăng số lượng trong giỏ.";
            return;
        }
    cart.push_back({id, 1, ""});
    message = L"Đã thêm món vào giỏ hàng.";
}
Money cartTotal() {
    Money n = 0;
    for (auto &c : cart)
        n += store->food(c.foodId).price * c.quantity;
    return n;
}
void top(Graphics &g) {
    button(g, L"←", 24, 20, 40, 32, [] { go(store->user(actor).admin ? AdminHome : Menu); });
    button(g, L"Đăng xuất", 72, 20, 98, 32, [] {
        actor = 0;
        cart.clear();
        go(Login);
    });
    if (!store->user(actor).admin) {
        button(g, L"Thực đơn", 180, 20, 100, 32, [] { go(Menu); });
        button(g, L"Lịch sử", 750, 20, 90, 32, [] { go(History); });
        button(g, L"Tài khoản", 850, 20, 100, 32, [] { go(Profile); });
        button(g, L"Giỏ (" + std::to_wstring(cart.size()) + L")", 960, 20, 110, 32,
               [] { go(Cart); });
    }
}
void sidebar(Graphics &g) {
    const std::vector<std::pair<std::wstring, Screen>> nav = {
        {L"Khách hàng", Customers}, {L"Món ăn", Foods},       {L"Đơn hàng", Orders},
        {L"Doanh thu", Revenue},    {L"Giảm giá", Discounts}, {L"Thêm món", EditFood}};
    for (size_t i = 0; i < nav.size(); i++) {
        auto [title, s] = nav[i];
        button(
            g, title, 25, 105 + (int)i * 49, 150, 30,
            [s] {
                editingFood = 0;
                go(s);
            },
            screen == s ? 3 : 0);
    }
    line(g, 195, 80, 195, 590);
}
void pages(Graphics &g, int count, int per, int x = 740) {
    int maxPage = std::max(0, (count - 1) / per);
    page = std::clamp(page, 0, maxPage);
    button(g, L"Trước", x, 572, 80, 30, [] {
        page = std::max(0, page - 1);
        refresh();
    });
    text(g, std::to_wstring(page + 1) + L" / " + std::to_wstring(maxPage + 1), (float)x + 85, 578,
         90, 24, 14, ink, false, 1);
    button(g, L"Sau", x + 180, 572, 80, 30, [maxPage] {
        page = std::min(maxPage, page + 1);
        refresh();
    });
}
std::wstring lower(std::wstring s) {
    for (auto &c : s)
        c = (wchar_t)towlower(c);
    return s;
}
std::vector<FoodItem> filteredFoods() {
    std::vector<FoodItem> a;
    auto q = lower(query);
    for (auto &f : store->data().foods)
        if ((screen != Menu || category == L"Tất cả" || w(f.category) == category) &&
            lower(w(f.name)).find(q) != std::wstring::npos)
            a.push_back(f);
    if (sortMode)
        std::sort(a.begin(), a.end(), [](auto &a, auto &b) {
            return sortMode == 1   ? a.price < b.price
                   : sortMode == 2 ? a.price > b.price
                                   : a.name < b.name;
        });
    return a;
}
void draw(Graphics &g) {
    buttons.clear();
    g.Clear(bg);
    g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
    if (actor && screen != Help)
        top(g);
    if (screen >= AdminHome && screen <= Orders)
        sidebar(g);
    switch (screen) {
    case Login: {
        text(g, L"WELCOME TO FOOD STORE", 565, 145, 470, 45, 24, ink, true);
        box(g, 100, 218, 170, 170, Color(255, 255, 240), true);
        text(g, L"ĐẠI HỌC\nBÁCH KHOA", 105, 245, 160, 80, 23, Color(25, 40, 150), true, 1);
        text(g, L"ĐÀ NẴNG", 105, 345, 160, 30, 19, Color(190, 30, 25), true, 1);
        box(g, 295, 218, 170, 170, Color::White, true);
        text(g, L"IT", 300, 235, 160, 80, 64, Color(30, 70, 170), true, 1);
        text(g, L"FACULTY", 300, 330, 160, 35, 24, ink, true, 1);
        button(
            g, L"Đăng nhập", 740, 370, 130, 36,
            [] {
                attempt([] {
                    actor = store->login(u8(value(1)), u8(value(2)));
                    go(store->user(actor).admin ? AdminHome : Menu);
                });
            },
            1);
        button(g, L"Đăng ký", 850, 420, 100, 29, [] { go(Register); });
        text(g, L"Bạn chưa có tài khoản?", 620, 425, 225, 25, 14);
        button(g, L"Hướng dẫn tài khoản", 750, 470, 200, 29, [] { go(Help); });
        text(g, L"PBL2 • Tô Đông Hải • 102250115", 0, 565, 1100, 30, 16, gray, false, 1);
        break;
    }
    case Register:
        button(g, L"← Đăng nhập", 30, 25, 140, 30, [] { go(Login); });
        text(g, L"ĐĂNG KÝ TÀI KHOẢN", 310, 90, 600, 40, 24, ink, true, 1);
        button(
            g, L"Đăng ký", 800, 410, 130, 36,
            [] {
                attempt([] {
                    require(value(5) == value(6), "Mat khau xac nhan khong khop");
                    store->registerUser(u8(value(1)), u8(value(2)), u8(value(3)), u8(value(4)),
                                        u8(value(5)));
                    go(Login);
                    message = L"Đăng ký thành công. Hãy đăng nhập.";
                });
            },
            1);
        break;
    case Menu: {
        std::vector<std::wstring> cats = {L"Tất cả", L"Món chính", L"Món phụ", L"Đồ uống",
                                          L"Tráng miệng"};
        for (size_t i = 0; i < cats.size(); i++) {
            auto c = cats[i];
            button(
                g, c, 28 + (int)i * 135, 70, 125, 28,
                [c] {
                    category = c;
                    page = 0;
                    refresh();
                },
                category == c ? 3 : 0);
        }
        button(g, L"Tìm", 1000, 70, 70, 30, [] {
            query = value(1);
            page = 0;
            refresh();
        });
        auto a = filteredFoods();
        pages(g, (int)a.size(), 8);
        for (int j = page * 8; j < std::min((int)a.size(), page * 8 + 8); j++) {
            auto f = a[j];
            int k = j % 8, x = 28 + (k % 4) * 265, y = 115 + (k / 4) * 220;
            box(g, (float)x, (float)y, 250, 205, Color::White);
            foodArt(g, f.art, (float)x + 55, (float)y + 5, 140, 110);
            button(g, w(f.name), x + 8, y + 116, 234, 27, [f] {
                selectedFood = f.id;
                go(Detail);
            });
            text(g, money(f.price), (float)x + 12, (float)y + 158, 130, 28, 17, red);
            button(
                g, f.available ? L"+ Giỏ" : L"Hết món", x + 155, y + 157, 85, 30,
                [f] { attempt([f] { addCart(f.id); }); }, f.available ? 1 : 3);
        }
        if (a.empty())
            text(g, L"Không có món phù hợp.", 50, 150, 700, 30, 20);
        break;
    }
    case Detail: {
        auto f = store->food(selectedFood);
        text(g, w(f.name), 32, 85, 1000, 40, 25, ink, true);
        box(g, 32, 140, 740, 330, Color(244, 176, 149));
        box(g, 55, 180, 280, 245, Color::White);
        foodArt(g, f.art, 65, 190, 260, 220);
        text(g, L"THÔNG TIN MÓN ĂN", 355, 175, 390, 40, 22, Color::White, true, 1);
        text(g, w(f.description), 355, 235, 380, 100, 18, ink);
        text(g, L"Danh mục: " + w(f.category), 355, 350, 380, 30, 17);
        text(g, f.available ? L"Trạng thái: Còn món" : L"Trạng thái: Ngừng bán", 355, 390, 380, 30,
             17);
        text(g, money(f.price), 810, 240, 230, 40, 26, red, true, 1);
        button(
            g, L"MUA NGAY", 810, 340, 230, 42,
            [] {
                attempt([] {
                    addCart(selectedFood);
                    go(Cart);
                });
            },
            1);
        button(
            g, L"Thêm vào giỏ hàng", 810, 395, 230, 36,
            [] { attempt([] { addCart(selectedFood); }); }, 1);
        break;
    }
    case Cart: {
        text(g, L"GIỎ HÀNG", 35, 75, 600, 35, 23, ink, true);
        box(g, 30, 115, 760, 440, Color::White);
        box(g, 810, 115, 260, 440, Color::White);
        pages(g, (int)cart.size(), 5, 40);
        for (int j = page * 5; j < std::min((int)cart.size(), page * 5 + 5); j++) {
            auto c = cart[j];
            auto f = store->food(c.foodId);
            int y = 125 + (j % 5) * 84;
            button(g, L"×", 38, y + 20, 30, 30, [j] {
                cart.erase(cart.begin() + j);
                refresh();
            });
            foodArt(g, f.art, 75, (float)y, 80, 70);
            text(g, w(f.name), 170, (float)y + 8, 300, 27, 17);
            text(g, money(f.price * c.quantity), 470, (float)y + 24, 140, 25, 16,
                 Color(45, 85, 215));
            button(g, L"−", 620, y + 20, 32, 28, [j] {
                if (cart[j].quantity > 1)
                    cart[j].quantity--;
                else
                    cart.erase(cart.begin() + j);
                refresh();
            });
            text(g, std::to_wstring(c.quantity), 655, (float)y + 23, 35, 25, 15, ink, false, 1);
            button(g, L"+", 695, y + 20, 32, 28, [j] {
                attempt([j] {
                    require(cart[j].quantity < 99, "Toi da 99 suat");
                    cart[j].quantity++;
                });
            });
            line(g, 80, (float)y + 78, 755, (float)y + 78);
        }
        text(g, L"TỔNG TIỀN", 830, 350, 220, 30, 17);
        text(g, money(cartTotal()), 830, 390, 220, 35, 23, Color(45, 85, 215), true);
        button(
            g, L"Thanh toán", 830, 450, 220, 40,
            [] {
                attempt([] {
                    require(!cart.empty(), "Gio hang trong");
                    go(Checkout);
                });
            },
            2);
        if (cart.empty())
            text(g, L"Giỏ hàng đang trống.", 65, 150, 650, 30, 20);
        break;
    }
    case Checkout:
        text(g, L"XÁC NHẬN ĐẶT MÓN", 260, 85, 700, 40, 25, ink, true, 1);
        text(g, L"Tạm tính: " + money(cartTotal()), 450, 345, 550, 35, 21);
        button(
            g, L"Tiền mặt", 450, 400, 180, 35,
            [] {
                method = "cash";
                refresh();
            },
            method == "cash" ? 3 : 0);
        button(
            g, L"Thanh toán mô phỏng", 650, 400, 245, 35,
            [] {
                method = "simulation";
                refresh();
            },
            method == "simulation" ? 3 : 0);
        text(g, L"Nhận món tại cửa hàng. Mô phỏng không chuyển tiền thật.", 300, 455, 730, 35, 15,
             gray);
        button(
            g, L"Đặt đơn hàng", 650, 510, 245, 40,
            [] {
                attempt([] {
                    selectedOrder =
                        store->place(actor, cart, u8(value(1)), u8(value(2)), u8(value(3)), method);
                    cart.clear();
                    go(OrderDetail);
                    message = L"Đã tạo đơn. Kiểm tra thanh toán bên dưới.";
                });
            },
            1);
        break;
    case History:
    case Orders: {
        bool adm = screen == Orders;
        int x = adm ? 220 : 35;
        text(g, adm ? L"QUẢN LÝ ĐƠN HÀNG" : L"LỊCH SỬ ĐẶT MÓN", (float)x, 78, 800, 35, 23, ink,
             true);
        std::vector<Order> a;
        for (auto it = store->data().orders.rbegin(); it != store->data().orders.rend(); ++it)
            if (adm || it->userId == actor)
                a.push_back(*it);
        pages(g, (int)a.size(), 8);
        box(g, (float)x, 125, 850, 34, Color(227, 228, 203), true);
        text(g, L"Mã đơn       Ngày đặt                          Tổng tiền              Trạng thái",
             (float)x + 10, 132, 800, 30, 16, ink, true);
        for (int j = page * 8; j < std::min((int)a.size(), page * 8 + 8); j++) {
            auto o = a[j];
            int y = 165 + (j % 8) * 48;
            text(g, L"#" + std::to_wstring(o.id), (float)x + 10, (float)y, 70, 28, 16);
            text(g, w(o.created), (float)x + 100, (float)y, 200, 28, 15);
            text(g, money(o.total), (float)x + 320, (float)y, 145, 28, 16);
            text(g, statusName(o.status), (float)x + 480, (float)y, 180, 28, 15);
            button(g, L"Chi tiết", x + 700, y - 2, 100, 30, [o] {
                selectedOrder = o.id;
                go(OrderDetail);
            });
            line(g, (float)x, (float)y + 38, (float)x + 850, (float)y + 38);
        }
        if (a.empty()) {
            text(g, L"Chưa có đơn hàng.", (float)x + 15, 190, 700, 30, 20);
        }
        break;
    }
    case OrderDetail: {
        auto o = store->order(actor, selectedOrder);
        bool paid = store->paid(o.id), adm = store->user(actor).admin;
        text(g, L"ĐƠN HÀNG #" + std::to_wstring(o.id), 35, 80, 700, 35, 24, ink, true);
        text(g, statusName(o.status) + (paid ? L" • Đã thanh toán" : L" • Chưa thanh toán"), 35,
             120, 1000, 30, 18, paid ? Color(30, 120, 60) : red);
        text(g, L"Người nhận: " + w(o.receiver) + L"  |  " + w(o.created), 35, 160, 1020, 28, 16);
        text(g, L"Ghi chú: " + w(o.note), 35, 192, 1000, 28, 16);
        pages(g, (int)o.items.size(), 5, 35);
        for (int j = page * 5; j < std::min((int)o.items.size(), page * 5 + 5); j++) {
            auto i = o.items[j];
            float y = 240.f + (j % 5) * 43;
            text(g, w(i.name), 45, y, 430, 30, 17);
            text(g, std::to_wstring(i.quantity) + L" × " + money(i.price), 480, y, 230, 30, 16);
            text(g, money(i.total()), 760, y, 280, 30, 17, ink, false, 2);
            line(g, 35, y + 34, 1060, y + 34);
        }
        text(g, L"Giảm: " + money(o.discount) + L"    Tổng thanh toán: " + money(o.total), 460, 475,
             600, 35, 21, red, true, 2);
        std::string m;
        for (auto &p : store->data().payments)
            if (p.orderId == o.id)
                m = p.method;
        text(g,
             m == "cash" ? L"Phương thức: Tiền mặt tại quầy"
                         : L"Phương thức: Mô phỏng - không chuyển tiền thật",
             460, 512, 600, 28, 15, gray, false, 2);
        if (!paid && o.status != 5 && (adm || m == "simulation")) {
            button(
                g, m == "cash" ? L"Xác nhận đã thu tiền" : L"Mô phỏng thành công", 550, 555, 225,
                36,
                [o] {
                    attempt([o] {
                        store->pay(actor, o.id, true, "OK-" + std::to_string(GetTickCount64()));
                        refresh();
                    });
                },
                1);
            if (m == "simulation")
                button(g, L"Mô phỏng thất bại", 795, 555, 210, 36, [o] {
                    attempt([o] {
                        store->pay(actor, o.id, false, "FAIL-" + std::to_string(GetTickCount64()));
                        message = L"Giao dịch mô phỏng thất bại. Có thể thử lại.";
                    });
                });
        } else if (adm && o.status < 4) {
            button(
                g, L"Chuyển trạng thái tiếp", 780, 555, 240, 36,
                [o] {
                    attempt([o] {
                        store->advance(actor, o.id);
                        refresh();
                    });
                },
                1);
        }
        if (adm && o.status < 3 && !paid)
            button(g, L"Tiếp nhận / chế biến", 280, 555, 220, 36, [o] {
                attempt([o] {
                    store->advance(actor, o.id);
                    refresh();
                });
            });
        if (o.status == 0 && !paid)
            button(g, L"Hủy đơn", 35, 525, 120, 30, [o] {
                attempt([o] {
                    if (MessageBoxW(windowHandle, L"Hủy đơn hàng này?", L"Xác nhận",
                                    MB_YESNO | MB_ICONQUESTION) == IDYES)
                        store->cancel(actor, o.id);
                    refresh();
                });
            });
        break;
    }
    case Profile: {
        auto u = store->user(actor);
        text(g, L"THÔNG TIN TÀI KHOẢN", 300, 105, 650, 40, 25, ink, true);
        text(g, L"Họ và tên: " + w(u.name), 300, 200, 650, 35, 20);
        text(g, L"Email: " + w(u.email), 300, 255, 650, 35, 20);
        text(g, L"Số điện thoại: " + w(u.phone), 300, 310, 650, 35, 20);
        text(g, L"Tên đăng nhập: " + w(u.login), 300, 365, 650, 35, 20);
        button(g, L"Đổi mật khẩu", 300, 445, 200, 38, [] { go(Password); }, 1);
        break;
    }
    case Password:
        text(g, L"ĐỔI MẬT KHẨU", 350, 105, 650, 40, 25, ink, true);
        button(
            g, L"Xác nhận", 700, 430, 150, 38,
            [] {
                attempt([] {
                    require(value(2) == value(3), "Mat khau xac nhan khong khop");
                    store->changePassword(actor, u8(value(1)), u8(value(2)));
                    go(Profile);
                    message = L"Đã đổi mật khẩu.";
                });
            },
            1);
        break;
    case AdminHome:
        text(g, L"QUẢN LÝ CỬA HÀNG", 260, 130, 750, 50, 27, ink, true);
        text(g, L"Tiếp nhận đơn • Quản lý thực đơn • Theo dõi thanh toán", 260, 195, 780, 45, 19,
             gray);
        text(g, L"Món ăn: " + std::to_wstring(store->data().foods.size()), 270, 300, 650, 40, 23);
        text(g, L"Đơn hàng: " + std::to_wstring(store->data().orders.size()), 270, 360, 650, 40,
             23);
        text(g, L"Tổng tiền đã thu: " + money(store->revenue()), 270, 420, 700, 40, 23, red, true);
        break;
    case Customers: {
        text(g, L"DANH SÁCH KHÁCH HÀNG", 220, 75, 800, 35, 22, ink, true);
        button(g, L"Tìm", 975, 120, 85, 32, [] {
            query = value(1);
            page = 0;
            refresh();
        });
        std::vector<User> a;
        for (auto &u : store->data().users)
            if (!u.admin && lower(w(u.name)).find(lower(query)) != std::wstring::npos)
                a.push_back(u);
        pages(g, (int)a.size(), 8);
        box(g, 220, 170, 850, 32, Color(227, 228, 203), true);
        text(g,
             L"Họ tên                                      Email                                   "
             L"   Số điện thoại",
             230, 176, 830, 30, 16, ink, true);
        for (int j = page * 8; j < std::min((int)a.size(), page * 8 + 8); j++) {
            auto u = a[j];
            int y = 210 + (j % 8) * 42;
            text(g, w(u.name), 230, (float)y, 300, 30, 16);
            text(g, w(u.email), 540, (float)y, 300, 30, 16);
            text(g, w(u.phone), 850, (float)y, 200, 30, 16);
            line(g, 220, (float)y + 34, 1070, (float)y + 34);
        }
        break;
    }
    case Foods: {
        text(g, L"DANH SÁCH MÓN ĂN", 220, 75, 800, 35, 22, ink, true);
        button(g, L"Tìm", 710, 120, 65, 32, [] {
            query = value(1);
            page = 0;
            refresh();
        });
        button(g, L"Giá ↑↓", 790, 120, 110, 32, [] {
            sortMode = sortMode == 1 ? 2 : 1;
            refresh();
        });
        button(g, L"Tên A-Z", 915, 120, 145, 32, [] {
            sortMode = 3;
            refresh();
        });
        auto a = filteredFoods();
        pages(g, (int)a.size(), 8);
        box(g, 220, 170, 850, 32, Color(227, 228, 203), true);
        text(g,
             L"Tên món                                  Danh mục           Giá bán             "
             L"Thao tác",
             230, 176, 830, 30, 16, ink, true);
        for (int j = page * 8; j < std::min((int)a.size(), page * 8 + 8); j++) {
            auto f = a[j];
            int y = 210 + (j % 8) * 42;
            text(g, w(f.name), 230, (float)y, 270, 28, 15);
            text(g, w(f.category), 505, (float)y, 150, 28, 15);
            text(g, money(f.price), 665, (float)y, 140, 28, 15);
            button(g, L"Sửa", 815, y - 2, 65, 28, [f] {
                editingFood = f.id;
                go(EditFood);
            });
            button(g, f.available ? L"Ngừng bán" : L"Mở bán", 890, y - 2, 160, 28, [f] {
                attempt([f] {
                    store->toggleFood(actor, f.id);
                    refresh();
                });
            });
            line(g, 220, (float)y + 34, 1070, (float)y + 34);
        }
        break;
    }
    case EditFood:
        text(g, editingFood ? L"CHỈNH SỬA THÔNG TIN MÓN ĂN" : L"THÊM MÓN ĂN", 260, 80, 800, 40, 23,
             ink, true, 1);
        text(g, L"Danh mục: Món chính / Món phụ / Đồ uống / Tráng miệng", 420, 445, 650, 35, 14,
             gray);
        button(
            g, L"Xác nhận", 830, 500, 170, 38,
            [] {
                attempt([] {
                    FoodItem f = editingFood ? store->food(editingFood) : FoodItem{};
                    f.name = u8(value(1));
                    f.category = u8(value(2));
                    f.price = number(3);
                    f.description = u8(value(4));
                    store->saveFood(actor, f);
                    go(Foods);
                    message = L"Đã lưu món ăn.";
                });
            },
            1);
        break;
    case Discounts:
        text(g, L"TẠO MÃ GIẢM GIÁ", 260, 80, 800, 40, 23, ink, true, 1);
        button(
            g, L"Cấp mã", 830, 345, 170, 38,
            [] {
                attempt([] {
                    auto n = number(3);
                    require(n > 0 && n <= 100000, "So luot khong hop le");
                    store->createDiscount(actor, u8(value(1)), number(2), (int)n);
                    go(Discounts);
                    message = L"Đã tạo mã giảm giá.";
                });
            },
            1);
        text(g, L"Mã hiện có", 260, 410, 700, 30, 19, ink, true);
        {
            int i = 0;
            for (auto &d : store->data().discounts) {
                if (i++ >= 4)
                    break;
                text(g,
                     w(d.code) + L"  •  " + money(d.amount) + L"  •  Còn " +
                         std::to_wstring(d.remaining) + L" lượt",
                     280, 445.f + (i - 1) * 32, 700, 30, 16);
            }
        }
        break;
    case Revenue: {
        text(g, L"THỐNG KÊ TIỀN ĐÃ THU", 230, 80, 800, 40, 23, ink, true);
        text(g, L"Tổng: " + money(store->revenue()), 245, 130, 780, 35, 24, red, true);
        text(g, L"Chỉ cộng giao dịch thành công; không cộng đơn chưa thanh toán.", 245, 180, 790,
             32, 15, gray);
        std::map<std::string, Money> days;
        for (auto &p : store->data().payments)
            if (p.status == 1)
                days[p.created.substr(0, 10)] += p.amount;
        while (days.size() > 7)
            days.erase(days.begin());
        line(g, 290, 500, 1030, 500);
        line(g, 290, 245, 290, 500);
        Money mx = 1;
        for (auto &[d, v] : days)
            mx = std::max(mx, v);
        int i = 0;
        for (auto &[d, v] : days) {
            float x = 320.f + i * 95, h = (float)v / (float)mx * 215;
            box(g, x, 500 - h, 58, h, Color(170, 30, 65));
            text(g, money(v), x - 20, 465 - h, 100, 30, 13, ink, false, 1);
            text(g, w(d.substr(5)), x - 8, 515, 80, 30, 14, ink, false, 1);
            i++;
        }
        if (days.empty())
            text(g, L"Chưa có giao dịch thành công.", 360, 350, 650, 40, 22, gray);
        break;
    }
    case Help:
        button(g, L"← Đăng nhập", 30, 25, 145, 32, [] { go(Login); });
        text(g, L"HƯỚNG DẪN SỬ DỤNG", 190, 100, 800, 45, 26, ink, true);
        text(g, L"Tài khoản mẫu khách hàng: khach / Khach@123", 190, 190, 850, 35, 21);
        text(g, L"Tài khoản mẫu quản trị: admin / Admin@123", 190, 250, 850, 35, 21);
        text(g,
             L"Đăng ký tài khoản mới hoặc dùng tài khoản mẫu để thử ứng dụng.\n\nThanh toán mô "
             L"phỏng không chuyển tiền thật. Tiền mặt cần người\nquản lý xác nhận đã nhận "
             L"tiền.\n\nChưa tích hợp khôi phục mật khẩu qua email. Với tài khoản thật,\nhãy lưu "
             L"mật khẩu cẩn thận; không xóa dữ liệu để đặt lại mật khẩu.",
             190, 320, 850, 230, 18);
        break;
    }
    for (auto &f : fields) {
        if (!f.label.empty())
            text(g, f.label, (float)f.x - 195, (float)f.y + 6, 185, 28, 16);
        if (exportMode) {
            box(g, (float)f.x, (float)f.y, (float)f.width, (float)f.height, Color::White, true);
            auto v = value(f.id);
            if (f.password)
                v = std::wstring(v.size(), L'•');
            text(g, v, (float)f.x + 6, (float)f.y + 6, (float)f.width - 12, 25, 17);
        }
    }
    if (!message.empty()) {
        box(g, 0, 613, 1100, 37, Color(237, 235, 206));
        text(g, message, 25, 621, 1050, 26, 15, Color(140, 40, 30));
    } else
        text(g, L"PBL2  |  Ứng dụng đặt món ăn và thanh toán đơn hàng", 25, 623, 1050, 25, 13,
             gray);
}
void go(Screen s) {
    for (auto &f : fields) {
        DestroyWindow(f.hwnd);
    }
    fields.clear();
    screen = s;
    page = 0;
    query.clear();
    message.clear();
    if (s == Login) {
        field(1, 740, 235, 245, L"Tên đăng nhập:");
        field(2, 740, 300, 245, L"Mật khẩu:", L"", true);
    }
    if (s == Register) {
        field(1, 455, 165, 310, L"Họ và tên:");
        field(2, 455, 220, 310, L"Email:");
        field(3, 455, 275, 310, L"Số điện thoại:");
        field(4, 455, 330, 310, L"Tên đăng nhập:");
        field(5, 455, 385, 310, L"Mật khẩu:", L"", true);
        field(6, 455, 440, 310, L"Nhập lại mật khẩu:", L"", true);
    }
    if (s == Menu)
        field(1, 740, 70, 250, L"");
    if (s == Checkout) {
        auto u = store->user(actor);
        field(1, 450, 165, 445, L"Người nhận / SĐT:", w(u.name + " - " + u.phone));
        field(2, 450, 225, 445, L"Ghi chú chế biến:");
        field(3, 450, 285, 445, L"Mã giảm giá:");
    }
    if (s == Password) {
        field(1, 530, 200, 320, L"Mật khẩu hiện tại:", L"", true);
        field(2, 530, 270, 320, L"Mật khẩu mới:", L"", true);
        field(3, 530, 340, 320, L"Nhập lại mật khẩu:", L"", true);
    }
    if (s == Customers)
        field(1, 220, 120, 740, L"");
    if (s == Foods)
        field(1, 220, 120, 475, L"");
    if (s == EditFood) {
        FoodItem f;
        if (editingFood)
            f = store->food(editingFood);
        field(1, 450, 175, 550, L"Tên món:", w(f.name));
        field(2, 450, 240, 550, L"Danh mục:", w(f.category));
        field(3, 450, 305, 550, L"Giá tiền (VND):", editingFood ? std::to_wstring(f.price) : L"");
        field(4, 450, 370, 550, L"Mô tả:", w(f.description));
    }
    if (s == Discounts) {
        field(1, 450, 165, 550, L"Mã giảm giá:");
        field(2, 450, 225, 550, L"Số tiền giảm:");
        field(3, 450, 285, 550, L"Số lượt sử dụng:");
    }
    refresh();
    if (!fields.empty())
        SetFocus(fields.front().hwnd);
}
LRESULT CALLBACK proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(hwnd, &ps);
        HDC mem = CreateCompatibleDC(dc);
        HBITMAP bmp = CreateCompatibleBitmap(dc, 1100, 650);
        auto old = SelectObject(mem, bmp);
        {
            Graphics g(mem);
            draw(g);
        }
        BitBlt(dc, 0, 0, 1100, 650, mem, 0, 0, SRCCOPY);
        SelectObject(mem, old);
        DeleteObject(bmp);
        DeleteDC(mem);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_ERASEBKGND:
        return 1;
    case WM_LBUTTONUP: {
        POINT p{(short)LOWORD(lp), (short)HIWORD(lp)};
        for (auto &b : buttons)
            if (PtInRect(&b.r, p)) {
                auto action = b.action;
                attempt(action);
                break;
            }
        return 0;
    }
    case WM_CTLCOLOREDIT:
        SetBkColor((HDC)wp, RGB(255, 255, 255));
        SetTextColor((HDC)wp, RGB(25, 25, 25));
        return (LRESULT)GetStockObject(WHITE_BRUSH);
    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcW(hwnd, msg, wp, lp);
    }
}
void saveShot(const std::wstring &name) {
    exportMode = true;
    Bitmap bmp(1100, 650, PixelFormat32bppARGB);
    {
        Graphics g(&bmp);
        draw(g);
    }
    CLSID png = {0x557cf406, 0x1a04, 0x11d3, {0x9a, 0x73, 0x00, 0x00, 0xf8, 0x1e, 0xf3, 0x2e}};
    auto p = base / L"report" / L"screenshots" / (name + L".png");
    require(bmp.Save(p.c_str(), &png, nullptr) == Ok, "Khong luu duoc anh PNG");
    exportMode = false;
}
void screenshots() {
    std::filesystem::create_directories(base / L"report" / L"screenshots");
    go(Login);
    setValue(1, L"khach");
    saveShot(L"01-login");
    go(Register);
    setValue(1, L"Tô Đông Hải");
    setValue(2, L"hai@food.local");
    setValue(3, L"0901234567");
    saveShot(L"02-register");
    actor = 2;
    go(Menu);
    saveShot(L"03-menu");
    selectedFood = 1;
    go(Detail);
    saveShot(L"04-detail");
    cart = {{1, 2, ""}, {5, 1, ""}, {7, 2, ""}};
    go(Cart);
    saveShot(L"05-cart");
    go(Checkout);
    setValue(3, L"HAI10");
    saveShot(L"06-checkout");
    selectedOrder = store->place(actor, cart, "Tô Đông Hải - 0901234567", "Ít cay, trà đào ít đá",
                                 "HAI10", "simulation");
    cart.clear();
    go(OrderDetail);
    saveShot(L"07-payment");
    store->pay(actor, selectedOrder, true, "DEMO-001");
    go(OrderDetail);
    saveShot(L"08-paid");
    go(History);
    saveShot(L"09-history");
    go(Profile);
    saveShot(L"10-profile");
    go(Password);
    saveShot(L"11-password");
    actor = 1;
    go(AdminHome);
    saveShot(L"12-admin");
    go(Customers);
    saveShot(L"13-customers");
    go(Foods);
    saveShot(L"14-foods");
    editingFood = 1;
    go(EditFood);
    saveShot(L"15-edit");
    editingFood = 0;
    go(EditFood);
    saveShot(L"16-add");
    go(Discounts);
    saveShot(L"17-discount");
    go(Orders);
    saveShot(L"18-orders");
    go(Revenue);
    saveShot(L"19-revenue");
    for (int i = 0; i < 4; i++) {
        store->advance(actor, selectedOrder);
    }
    go(OrderDetail);
    saveShot(L"20-complete");
}
void uiTest() {
    std::ofstream log(base / L"tests" / L"ui-results.txt");
    auto check = [&](bool ok, const char *name) {
        require(ok, name);
        log << "PASS " << name << '\n';
        log.flush();
    };
    auto click = [&](int x, int y) {
        Bitmap b(1100, 650, PixelFormat32bppARGB);
        {
            Graphics g(&b);
            draw(g);
        }
        SendMessageW(windowHandle, WM_LBUTTONUP, 0, MAKELPARAM(x, y));
    };
    go(Login);
    setValue(1, L"khach");
    setValue(2, L"Khach@123");
    click(800, 388);
    check(screen == Menu && actor == 2, "login button opens customer menu");
    click(220, 287);
    check(cart.size() == 1, "add button updates cart");
    click(1000, 35);
    check(screen == Cart, "cart navigation");
    click(945, 468);
    check(screen == Checkout, "checkout navigation");
    click(760, 417);
    check(method == "simulation", "payment selection");
    click(770, 525);
    check(screen == OrderDetail && cart.empty(), "place order button persists and clears cart");
    click(650, 570);
    check(store->paid(selectedOrder), "simulation button pays order");
    click(120, 35);
    check(screen == Login && actor == 0, "logout clears session");
    setValue(1, L"admin");
    setValue(2, L"Admin@123");
    click(800, 388);
    check(screen == AdminHome && actor == 1, "admin login routes correctly");
    click(100, 165);
    check(screen == Foods, "admin food navigation");
    log << "TOTAL 10 PASS\n";
}
int WINAPI wWinMain(HINSTANCE h, HINSTANCE, LPWSTR args, int show) {
    try {
        wchar_t exe[MAX_PATH];
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        base = std::filesystem::path(exe).parent_path();
        bool uitest = std::wstring(args).find(L"--ui-test") != std::wstring::npos;
        bool shots = uitest || std::wstring(args).find(L"--screenshots") != std::wstring::npos;
        HANDLE mutex = nullptr;
        if (!shots) {
            mutex = CreateMutexW(nullptr, TRUE, L"Local\\PBL2FoodOrderHai102250115");
            if (GetLastError() == ERROR_ALREADY_EXISTS) {
                MessageBoxW(nullptr, L"Ứng dụng đang chạy.", L"FoodOrder", MB_OK);
                return 0;
            }
        }
        store = std::make_unique<Store>(
            (shots ? base / L"report" / L"qa-data" /
                         (L"run-" + std::to_wstring(GetTickCount64()) + L".txt")
                   : base / L"data" / L"store.txt"));
        GdiplusStartupInput in;
        ULONG_PTR token;
        require(GdiplusStartup(&token, &in, nullptr) == Ok, "Loi do hoa");
        editFont = CreateFontW(-18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                               DEFAULT_PITCH, L"Arial");
        WNDCLASSW cls{};
        cls.lpfnWndProc = proc;
        cls.hInstance = h;
        cls.lpszClassName = L"FoodOrderClass";
        cls.hCursor = LoadCursor(nullptr, IDC_ARROW);
        RegisterClassW(&cls);
        RECT r{0, 0, 1100, 650};
        DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
        AdjustWindowRect(&r, style, FALSE);
        windowHandle = CreateWindowW(cls.lpszClassName, L"FoodOrder - PBL2 - Tô Đông Hải", style,
                                     CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left,
                                     r.bottom - r.top, nullptr, nullptr, h, nullptr);
        require(windowHandle != nullptr, "Khong tao duoc cua so");
        go(Login);
        if (shots) {
            if (uitest)
                uiTest();
            else
                screenshots();
            DestroyWindow(windowHandle);
        } else {
            ShowWindow(windowHandle, show);
            MSG msg{};
            while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
                if (!IsDialogMessageW(windowHandle, &msg)) {
                    TranslateMessage(&msg);
                    DispatchMessageW(&msg);
                }
            }
        }
        DeleteObject(editFont);
        GdiplusShutdown(token);
        if (mutex) {
            ReleaseMutex(mutex);
            CloseHandle(mutex);
        }
        return 0;
    } catch (const std::exception &e) {
        MessageBoxW(nullptr, w(e.what()).c_str(), L"Lỗi khởi động", MB_OK | MB_ICONERROR);
        return 1;
    }
}
